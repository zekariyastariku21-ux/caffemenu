require('dotenv').config();

const express = require('express');
const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');
const jwt = require('jsonwebtoken');
function encryptTelebirrSecret(value) {
  if (typeof value !== 'string' || !value.trim()) {
    throw new Error('A non-empty secret is required for encryption.');
  }

  const configuredKey =
    process.env.TELEBIRR_SETTINGS_ENCRYPTION_KEY || '';

  if (!/^[a-f0-9]{64}$/i.test(configuredKey)) {
    throw new Error(
      'TELEBIRR_SETTINGS_ENCRYPTION_KEY must be a 32-byte hex key.'
    );
  }

  const key = Buffer.from(configuredKey, 'hex');
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([
    cipher.update(value, 'utf8'),
    cipher.final()
  ]);
  const tag = cipher.getAuthTag();

  return [
    'v1',
    iv.toString('hex'),
    tag.toString('hex'),
    encrypted.toString('hex')
  ].join(':');
}

function isValidTelebirrUrl(value) {
  if (typeof value !== 'string' || !value.trim()) return true;

  try {
    const parsed = new URL(value.trim());
    return parsed.protocol === 'https:' ||
      (
        parsed.protocol === 'http:' &&
        ['localhost', '127.0.0.1', '::1'].includes(parsed.hostname)
      );
  } catch {
    return false;
  }
}
const crypto = require('crypto');

const app = express();

/* ================================================================
   DATABASE
   ================================================================ */

const pool = new Pool({

  connectionString: process.env.DATABASE_URL,

  ssl: process.env.DATABASE_URL
    ? { rejectUnauthorized: false }
    : false,

  /* ============================================================
     DATABASE CONNECTION SETTINGS
     ============================================================ */

  connectionTimeoutMillis: 15000,

  /*
     Keep idle connections alive so requests can reuse an
     already-established PostgreSQL connection.
  */
  idleTimeoutMillis: 120000,

  /*
     Do not let a normal query remain stuck indefinitely.
  */
  query_timeout: 30000,

  /*
     Keep a small pool of reusable connections.
  */
  max: 10,

  /*
     TCP keep-alive helps prevent long-lived connections from
     silently becoming stale.
  */
  keepAlive: true,
  keepAliveInitialDelayMillis: 10000

});

pool.on('error', error => {
  console.error(
    '[db] Idle PostgreSQL client error:',
    error.message
  );
});


/* ================================================================
   MENU CACHE
   ================================================================ */

const menuCache = new Map();

const companySettingsCache = {
  data: null
};



/* ================================================================
   DATABASE CONNECTION WARM-UP
   Keeps one PostgreSQL connection ready so the first customer
   request does not have to wait for the initial DB connection.
   ================================================================ */

async function warmDatabaseConnection() {
  try {
    const start = Date.now();

    await pool.query('SELECT 1');

    console.log(
      `[db] Database connection warmed up in ${Date.now() - start} ms.`
    );
  } catch (error) {
    console.error(
      '[db] Database warm-up failed:',
      error.message
    );
  }
}
/* ================================================================
   WARM PUBLIC MENU CACHE
   Loads active restaurant menus into memory after startup.
   This prevents the first customer request from waiting on
   PostgreSQL's initial connection/query latency.
   ================================================================ */

async function warmMenuCache() {
  try {
    console.log(
      '[menu:cache] Starting public menu cache warm-up...'
    );

    const result = await pool.query(`
      SELECT
        r.id,
        r.name,
        r.slug,
        r.status,

        md.menu,
        md.updated_at AS menu_updated_at,

        rp.logo,
        rp.phone_numbers,
        rp.addresses,
        rp.updated_at AS profile_updated_at,

        ra.header_background,
        ra.restaurant_name AS appearance_restaurant_name,
        ra.restaurant_name_text,
        ra.button_background,
        ra.button_text,
        ra.selected_button,
        ra.selected_button_text,
        ra.add_button_background,
        ra.add_button_text,
        ra.cart_button_background,
        ra.cart_button_text,
        ra.card_background,
        ra.item_name,
        ra.description,
        ra.price,
        ra.page_background

      FROM restaurants r

      LEFT JOIN menu_data md
        ON md.restaurant_id = r.id

      LEFT JOIN restaurant_profiles rp
        ON rp.restaurant_id = r.id

      LEFT JOIN restaurant_appearances ra
        ON ra.restaurant_id = r.id

      WHERE r.status = 'active'

      ORDER BY r.id
    `);

    let cachedCount = 0;

    for (const row of result.rows) {
      const responseData = {
        ok: true,

        restaurant: {
          id: row.id,
          name: row.name,
          slug: row.slug,
          status: row.status
        },

        menu:
          row.menu &&
          typeof row.menu === 'object'
            ? row.menu
            : {},

        menuUpdatedAt:
          row.menu_updated_at || null,

        profile: {
          logo:
            typeof row.logo === 'string'
              ? row.logo
              : '',

          phone_numbers:
            Array.isArray(row.phone_numbers)
              ? row.phone_numbers
              : [],

          addresses:
            Array.isArray(row.addresses)
              ? row.addresses
              : [],

          updated_at:
            row.profile_updated_at || null



        },

        appearance:
          row.header_background
            ? {
                header_background: row.header_background,
                restaurant_name: row.appearance_restaurant_name,
                restaurant_name_text: row.restaurant_name_text,
                button_background: row.button_background,
                button_text: row.button_text,
                selected_button: row.selected_button,
                selected_button_text: row.selected_button_text,
                add_button_background: row.add_button_background,
                add_button_text: row.add_button_text,
                cart_button_background: row.cart_button_background,
                cart_button_text: row.cart_button_text,
                card_background: row.card_background,
                item_name: row.item_name,
                description: row.description,
                price: row.price,
                page_background: row.page_background
              }
            : null
      };

      menuCache.set(
        row.slug,
        responseData
      );

      cachedCount++;

      console.log(
        `[menu:cache] Cached: ${row.slug}`
      );
    }

    console.log(
      `[menu:cache] Warm-up complete. Cached ${cachedCount} active restaurant(s).`
    );

  } catch (error) {
    console.error(
      '[menu:cache] Warm-up failed:',
      error.message
    );

    console.log(
      '[menu:cache] Server will continue normally. Menus will load on demand.'
    );
  }
}



/* ================================================================
   BASIC APP SETTINGS
   ================================================================ */

app.set('trust proxy', 1);

app.use(
  express.json({
    limit: '50mb'
  })
);

app.use(
  express.urlencoded({
    extended: true,
    limit: '50mb'
  })
);


/* ================================================================
   CORS
   ================================================================ */

app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');

  res.header(
    'Access-Control-Allow-Methods',
    'GET,POST,PUT,DELETE,OPTIONS'
  );

  res.header(
    'Access-Control-Allow-Headers',
    'Content-Type, Authorization'
  );

  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }

  next();
});


/* ================================================================
   REQUEST LOGGER
   ================================================================ */

app.use((req, res, next) => {
  console.log(
    `[req] ${req.method} ${req.originalUrl}`
  );

  next();
});


/* ================================================================
   DATABASE INITIALIZATION
   ================================================================ */

async function ensureDatabaseStructure() {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS restaurant_profiles (
        id SERIAL PRIMARY KEY,
        restaurant_id INTEGER NOT NULL UNIQUE
          REFERENCES restaurants(id) ON DELETE CASCADE,
        logo TEXT NOT NULL DEFAULT '',
        phone_numbers JSONB NOT NULL DEFAULT '[]'::jsonb,
        addresses JSONB NOT NULL DEFAULT '[]'::jsonb,
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
      )
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS restaurant_payment_settings (
        id SERIAL PRIMARY KEY,
        restaurant_id INTEGER NOT NULL UNIQUE
          REFERENCES restaurants(id) ON DELETE CASCADE,
        telebirr_enabled BOOLEAN NOT NULL DEFAULT FALSE,
        order_now_enabled BOOLEAN NOT NULL DEFAULT TRUE,
        merchant_name TEXT NOT NULL DEFAULT '',
        merchant_code TEXT NOT NULL DEFAULT '',
        merchant_app_id TEXT NOT NULL DEFAULT '',
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
      )
    `);

    await pool.query(`
      ALTER TABLE restaurant_payment_settings
      ADD COLUMN IF NOT EXISTS order_now_enabled BOOLEAN NOT NULL DEFAULT TRUE,
      ADD COLUMN IF NOT EXISTS super_admin_order_now_enabled BOOLEAN NOT NULL DEFAULT TRUE,
      ADD COLUMN IF NOT EXISTS fabric_app_id TEXT NOT NULL DEFAULT '',
      ADD COLUMN IF NOT EXISTS api_base_url TEXT NOT NULL DEFAULT '',
      ADD COLUMN IF NOT EXISTS notification_url TEXT NOT NULL DEFAULT '',
      ADD COLUMN IF NOT EXISTS return_url TEXT NOT NULL DEFAULT '',
      ADD COLUMN IF NOT EXISTS app_secret_encrypted TEXT NOT NULL DEFAULT '',
      ADD COLUMN IF NOT EXISTS private_key_encrypted TEXT NOT NULL DEFAULT ''
    `);

    await pool.query(`
      ALTER TABLE restaurant_profiles
      ADD COLUMN IF NOT EXISTS logo TEXT NOT NULL DEFAULT ''
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS company_settings (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        company_name TEXT NOT NULL DEFAULT '',
        slogan TEXT NOT NULL DEFAULT '',
        phone TEXT NOT NULL DEFAULT '',
        email TEXT NOT NULL DEFAULT '',
        address TEXT NOT NULL DEFAULT '',
        logo TEXT NOT NULL DEFAULT '',
        about TEXT NOT NULL DEFAULT '',
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
      )
    `);
    
        await pool.query(`
      ALTER TABLE company_settings
      ADD COLUMN IF NOT EXISTS logo TEXT NOT NULL DEFAULT ''
    `);

        await pool.query(`
          ALTER TABLE company_settings
          ADD COLUMN IF NOT EXISTS default_image TEXT NOT NULL DEFAULT ''
        `);


        await pool.query(`
          ALTER TABLE company_settings
      ADD COLUMN IF NOT EXISTS about TEXT NOT NULL DEFAULT ''
    `);
        await pool.query(`
      ALTER TABLE company_settings
      ADD COLUMN IF NOT EXISTS addresses JSONB NOT NULL DEFAULT '[]'::jsonb
    `);

    await pool.query(`
      ALTER TABLE company_settings
      ADD COLUMN IF NOT EXISTS phone_numbers JSONB NOT NULL DEFAULT '[]'::jsonb
    `);

    await pool.query(`
      ALTER TABLE company_settings
      ADD COLUMN IF NOT EXISTS company_content JSONB NOT NULL DEFAULT '{}'::jsonb
    `);
    await pool.query(`
      CREATE TABLE IF NOT EXISTS restaurant_appearances (
        id SERIAL PRIMARY KEY,
        restaurant_id INTEGER NOT NULL UNIQUE
          REFERENCES restaurants(id) ON DELETE CASCADE,

        header_background TEXT,
        header_background_type TEXT NOT NULL DEFAULT 'solid',
        restaurant_name TEXT,
        restaurant_name_type TEXT NOT NULL DEFAULT 'solid',
        restaurant_name_text TEXT,

        button_background TEXT,
        button_background_type TEXT NOT NULL DEFAULT 'solid',
        button_text TEXT,
        selected_button TEXT,
        selected_button_type TEXT NOT NULL DEFAULT 'solid',
        selected_button_text TEXT,
        add_button_background TEXT,
        add_button_text TEXT,
        cart_button_background TEXT,
        cart_button_text TEXT,

        card_background TEXT,
        card_background_type TEXT NOT NULL DEFAULT 'solid',
        item_name TEXT,
        description TEXT,
        price TEXT,

        page_background TEXT,
        page_background_type TEXT NOT NULL DEFAULT 'solid',

        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
      )
    `);

    await pool.query(`
      ALTER TABLE restaurant_appearances
        ADD COLUMN IF NOT EXISTS add_button_background TEXT,
        ADD COLUMN IF NOT EXISTS add_button_text TEXT,
        ADD COLUMN IF NOT EXISTS cart_button_background TEXT,
        ADD COLUMN IF NOT EXISTS cart_button_text TEXT
    `);

    await pool.query(`
      ALTER TABLE restaurant_appearances
        ADD COLUMN IF NOT EXISTS header_background_type TEXT,
        ADD COLUMN IF NOT EXISTS restaurant_name_type TEXT,
        ADD COLUMN IF NOT EXISTS button_background_type TEXT,
        ADD COLUMN IF NOT EXISTS selected_button_type TEXT,
        ADD COLUMN IF NOT EXISTS card_background_type TEXT,
        ADD COLUMN IF NOT EXISTS page_background_type TEXT,
        ALTER COLUMN header_background_type SET DEFAULT 'solid',
        ALTER COLUMN restaurant_name_type SET DEFAULT 'solid',
        ALTER COLUMN button_background_type SET DEFAULT 'solid',
        ALTER COLUMN selected_button_type SET DEFAULT 'solid',
        ALTER COLUMN card_background_type SET DEFAULT 'solid',
        ALTER COLUMN page_background_type SET DEFAULT 'solid'
    `);

    await pool.query(`
      UPDATE restaurant_appearances
      SET
        header_background_type = CASE
          WHEN header_background LIKE 'linear-gradient(%' THEN 'gradient'
          ELSE 'solid'
        END,
        restaurant_name_type = CASE
          WHEN restaurant_name LIKE 'linear-gradient(%' THEN 'gradient'
          ELSE 'solid'
        END,
        button_background_type = CASE
          WHEN button_background LIKE 'linear-gradient(%' THEN 'gradient'
          ELSE 'solid'
        END,
        selected_button_type = CASE
          WHEN selected_button LIKE 'linear-gradient(%' THEN 'gradient'
          ELSE 'solid'
        END,
        card_background_type = CASE
          WHEN card_background LIKE 'linear-gradient(%' THEN 'gradient'
          ELSE 'solid'
        END,
        page_background_type = CASE
          WHEN page_background LIKE 'linear-gradient(%' THEN 'gradient'
          ELSE 'solid'
        END
    `);

    await pool.query(`
      ALTER TABLE restaurant_appearances
        ALTER COLUMN header_background_type SET NOT NULL,
        ALTER COLUMN restaurant_name_type SET NOT NULL,
        ALTER COLUMN button_background_type SET NOT NULL,
        ALTER COLUMN selected_button_type SET NOT NULL,
        ALTER COLUMN card_background_type SET NOT NULL,
        ALTER COLUMN page_background_type SET NOT NULL
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS restaurant_appearance_history (
        id SERIAL PRIMARY KEY,
        restaurant_id INTEGER NOT NULL
          REFERENCES restaurants(id) ON DELETE CASCADE,

        appearance JSONB NOT NULL,

        created_at TIMESTAMP NOT NULL DEFAULT NOW()
      )
    `);

    console.log('[db] Database structure checked.');
  } catch (error) {
    console.error(
      '[db] Database structure check failed:',
      error
    );
  }
}


/* ================================================================
   AUTH HELPERS
   ================================================================ */

function getTokenFromRequest(req) {
  const authHeader = req.headers.authorization;

  if (
    authHeader &&
    authHeader.startsWith('Bearer ')
  ) {
    return authHeader.substring(7);
  }

  if (req.cookies && req.cookies.adminToken) {
    return req.cookies.adminToken;
  }

  const cookieHeader = req.headers.cookie || '';

  const match = cookieHeader.match(
    /(?:^|;\s*)adminToken=([^;]+)/
  );

  if (match) {
    return decodeURIComponent(match[1]);
  }

  return null;
}

function isSuperAdminRole(role) {
  const normalizedRole = String(role || '')
    .trim()
    .toLowerCase()
    .replace(/[\s-]+/g, '_');

  return normalizedRole === 'super_admin' ||
    normalizedRole === 'superadmin' ||
    normalizedRole === 'owner';
}


function requireOwner(req, res, next) {
  console.log('[auth:owner] Checking owner authentication...');

  const token = getTokenFromRequest(req);

  console.log('[auth:owner] Token exists:', !!token);

  if (!token) {
    console.log('[auth:owner] No token found.');
    return res.status(401).json({
      ok: false,
      message: 'Authentication required.'
    });
  }

  try {
    console.log('[auth:owner] Verifying JWT...');

    const decoded = jwt.verify(
      token,
      process.env.JWT_SECRET
    );

    console.log('[auth:owner] JWT decoded:', {
      id: decoded.id,
      email: decoded.email,
      role: decoded.role,
      restaurant_id: decoded.restaurant_id
    });

    if (!isSuperAdminRole(decoded.role)) {
      console.log('[auth:owner] Role rejected:', decoded.role);
      return res.status(403).json({
        ok: false,
        message: 'Super admin access required.'
      });
    }

    req.user = decoded;

    console.log('[auth:owner] Owner authentication successful.');
    next();

  } catch (error) {
    console.error('[auth:owner] JWT verification failed:', error.message);

    return res.status(401).json({
      ok: false,
      message: 'Invalid or expired authentication token.'
    });
  }
}

async function requireSuperAdminPassword(req, res, next) {
  if (!isSuperAdminRole(req.user.role)) {
    return res.status(403).json({
      ok: false,
      message: 'Super admin access required.'
    });
  }

  const password =
    req.body?.superAdminPassword ??
    req.headers['x-super-admin-password'];

  if (typeof password !== 'string' || password.length === 0) {
    return res.status(400).json({
      ok: false,
      message: 'Enter your super admin password to continue.'
    });
  }

  try {
    const result = await pool.query(`
      SELECT password, role
      FROM users
      WHERE id = $1
      LIMIT 1
    `, [
      req.user.id
    ]);

    if (result.rows.length === 0) {
      return res.status(403).json({
        ok: false,
        message: 'Super admin account not found.'
      });
    }

    if (!isSuperAdminRole(result.rows[0].role)) {
      return res.status(403).json({
        ok: false,
        message: 'Super admin access required.'
      });
    }

    if (result.rows[0].password !== password) {
      return res.status(401).json({
        ok: false,
        message: 'Super admin password is incorrect.'
      });
    }

    return next();
  } catch (error) {
    console.error(
      '[auth:super-admin-password] Verification failed:',
      error
    );

    return res.status(500).json({
      ok: false,
      message: 'Unable to verify your super admin password.'
    });
  }
}


async function requireRestaurantAdmin(
  req,
  res,
  next
) {
  const token = getTokenFromRequest(req);

  if (!token) {
    return res.status(401).json({
      ok: false,
      message: 'Authentication required.'
    });
  }

  try {
    const decoded = jwt.verify(
      token,
      process.env.JWT_SECRET
    );

    if (
      !isSuperAdminRole(decoded.role) &&
      decoded.role !== 'cafe_admin'
    ) {
      return res.status(403).json({
        ok: false,
        message: 'Administrator access required.'
      });
    }

    req.user = decoded;

    next();

  } catch (error) {
    console.error(
      '[auth] Restaurant admin token verification failed:',
      error.message
    );

    return res.status(401).json({
      ok: false,
      message: 'Invalid or expired authentication token.'
    });
  }
}


function requireCafeDashboardAccess(
  req,
  res,
  next
) {
  const token = getTokenFromRequest(req);

  if (!token) {
    return res.redirect('/admin.html');
  }

  try {
    const decoded = jwt.verify(
      token,
      process.env.JWT_SECRET
    );

    if (decoded.role !== 'cafe_admin') {
      return res.redirect('/admin.html');
    }

    req.user = decoded;
    next();

  } catch (error) {
    return res.redirect('/admin.html');
  }
}





/* ================================================================
   PROTECTED ADMIN HTML PAGES
   ================================================================ */

app.get('/admin-panel.html', (req, res) => {
  return res.redirect('/admin.html');
});



app.get(
  '/cafe-dashboard',
  requireCafeDashboardAccess,
  (req, res) => {
    if (req.user.role !== 'cafe_admin') {
      return res.redirect('/admin.html');
    }

    return res.sendFile(
      path.join(__dirname, 'admin-panel.html')
    );
  }
);


app.get('/super-admin-panel.html', (req, res) => {
  return res.redirect('/admin.html');
});

app.get(
  '/super-admin-dashboard',
  requireOwner,
  (req, res) => {
    return res.sendFile(
      path.join(__dirname, 'super-admin.html')
    );
  }
);


/* ================================================================
   ADMIN LOGIN PAGE
   ================================================================ */

app.get('/admin.html', (req, res) => {
  return res.sendFile(
    path.join(__dirname, 'admin.html')
  );
});


/* ================================================================
   BLOCK DIRECT SAVE.HTML ACCESS
   ================================================================ */

app.get('/save.html', (req, res) => {
  return res.status(404).send('Not Found');
});


/* ================================================================
   STATIC FILES
   ================================================================ */

app.use(express.static(__dirname));


/* ================================================================
   COMPANY HOME PAGE
   ================================================================ */

app.get('/', (req, res) => {
  return res.sendFile(
    path.join(__dirname, 'company.html')
  );
});


/* ================================================================
   PUBLIC RESTAURANT SLUG ROUTE
   ================================================================ */

app.get('/:slug', (req, res, next) => {
  const { slug } = req.params;

  if (
    slug === 'api' ||
    slug === 'admin.html' ||
    slug === 'admin-panel.html' ||
    slug === 'super-admin-panel.html' ||
    slug === 'save.html'
  ) {
    return next();
  }

  return res.sendFile(
    path.join(__dirname, 'save.html')
  );
});


/* ================================================================
   ADMIN LOGIN
   ================================================================ */

app.post(
  '/api/admin/login',
  async (req, res) => {
    try {
      const {
        email,
        password
      } = req.body;
if (!email || !password) {
        return res.status(400).json({
          ok: false,
          message: 'Email and password are required.'
        });
      }

      const cleanEmail =
        String(email)
          .trim()
          .toLowerCase();

      const result = await pool.query(`
        SELECT
          u.id,
          u.email,
          u.password,
          u.role,
          u.restaurant_id,
          r.name AS restaurant_name,
          r.slug AS restaurant_slug,
          r.status AS restaurant_status
        FROM users u
        LEFT JOIN restaurants r
          ON r.id = u.restaurant_id
        WHERE LOWER(u.email) = LOWER($1)
        LIMIT 1
      `, [
        cleanEmail
      ]);

      if (result.rows.length === 0) {
        return res.status(401).json({
          ok: false,
          message: 'Invalid email or password.'
        });
      }

      const user = result.rows[0];
      const sessionRole = isSuperAdminRole(user.role)
        ? 'super_admin'
        : user.role;

      /*
       * Current project authentication uses the password
       * stored in the database.
       */
      if (user.password !== password) {
        return res.status(401).json({
          ok: false,
          message: 'Invalid email or password.'
        });
      }

      if (
        user.role === 'cafe_admin' &&
        user.restaurant_status !== 'active'
      ) {
        return res.status(403).json({
          ok: false,
          message: 'This restaurant is currently disabled.'
        });
      }

      const token = jwt.sign(
        {
          id: user.id,
          email: user.email,
          role: sessionRole,
          restaurant_id: user.restaurant_id
        },
        process.env.JWT_SECRET,
        {
          expiresIn: '30d'
        }
      );

      res.cookie(
        'adminToken',
        token,
        {
          httpOnly: true,
          sameSite: 'lax',
          secure: process.env.NODE_ENV === 'production',
          maxAge: 7 * 24 * 60 * 60 * 1000
        }
      );

      return res.json({
        ok: true,
        message: 'Login successful.',
        token,
        role: sessionRole,
        restaurantId: user.restaurant_id,
        restaurantSlug: user.restaurant_slug,
        restaurantName: user.restaurant_name
      });

    } catch (error) {
      console.error(
        '[login] Error:',
        error
      );

      return res.status(500).json({
        ok: false,
        message: 'Login failed.'
      });
    }
  }
);





/* ================================================================
   ADMIN LOGOUT
   ================================================================ */

app.post(
  '/api/admin/logout',
  (req, res) => {
    res.clearCookie(
      'adminToken',
      {
        httpOnly: true,
        sameSite: 'lax',
        secure: process.env.NODE_ENV === 'production'
      }
    );

    return res.json({
      ok: true,
      message: 'Logged out successfully.'
    });
  }
);


/* ================================================================
   ADMIN SESSION
   ================================================================ */

app.get(
  '/api/admin/session',
  requireRestaurantAdmin,
  async (req, res) => {
    try {
      const result = await pool.query(`
        SELECT
          u.id,
          u.email,
          u.role,
          u.restaurant_id,
          r.name AS restaurant_name,
          r.slug AS restaurant_slug,
          r.status AS restaurant_status,
          r.menu_expires_at,
          r.menu_expires_at - (NOW() AT TIME ZONE 'UTC')::date
            AS menu_days_remaining
        FROM users u
        LEFT JOIN restaurants r
          ON r.id = u.restaurant_id
        WHERE u.id = $1
        LIMIT 1
      `, [
        req.user.id
      ]);

      if (result.rows.length === 0) {
        return res.status(401).json({
          ok: false,
          message: 'User account no longer exists.'
        });
      }

      const user = result.rows[0];
      const sessionRole = isSuperAdminRole(user.role)
        ? 'super_admin'
        : user.role;

      if (
        user.role === 'cafe_admin' &&
        user.restaurant_status !== 'active'
      ) {
        return res.status(403).json({
          ok: false,
          message: 'This restaurant is disabled.'
        });
      }

      return res.json({
        ok: true,
        user: {
          id: user.id,
          email: user.email,
          role: sessionRole,
          restaurantId: user.restaurant_id,
          restaurantName: user.restaurant_name,
          restaurantSlug: user.restaurant_slug,
          restaurantStatus: user.restaurant_status,
          menuExpirationDate: user.menu_expires_at,
          menuDaysRemaining: user.menu_days_remaining
        }
      });

    } catch (error) {
      console.error(
        '[session] Error:',
        error
      );

      return res.status(500).json({
        ok: false,
        message: 'Unable to load session.'
      });
    }
  }
);


/* ================================================================
   SUPER ADMIN ACCOUNT SETTINGS
   ================================================================ */

app.put(
  '/api/owner/account',
  requireOwner,
  async (req, res) => {
    try {
      if (!isSuperAdminRole(req.user.role)) {
        return res.status(403).json({
          ok: false,
          message: 'Super admin access required.'
        });
      }

      const email =
        String(req.body.email || '')
          .trim()
          .toLowerCase();

      const currentPassword =
        String(req.body.currentPassword || '');

      const newPassword =
        String(req.body.newPassword || '');

      const defaultImageProvided =
        Object.prototype.hasOwnProperty.call(
          req.body,
          'defaultImage'
        );

      const defaultImage =
        defaultImageProvided
          ? String(req.body.defaultImage || '')
          : '';

      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        return res.status(400).json({
          ok: false,
          message: 'Enter a valid email address.'
        });
      }

      if (!currentPassword) {
        return res.status(400).json({
          ok: false,
          message: 'Enter your current password to continue.'
        });
      }

      if (newPassword && newPassword.length < 6) {
        return res.status(400).json({
          ok: false,
          message: 'The new password must contain at least 6 characters.'
        });
      }

      if (
        defaultImageProvided &&
        defaultImage &&
        (
          !/^data:image\/(?:jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(defaultImage) ||
          Math.floor((defaultImage.split(',')[1].length * 3) / 4) > 5 * 1024 * 1024
        )
      ) {
        return res.status(400).json({
          ok: false,
          message: 'Choose a JPEG, PNG, or WebP image smaller than 5 MB.'
        });
      }

      const userResult = await pool.query(`
        SELECT
          id,
          email,
          password,
          role,
          restaurant_id
        FROM users
        WHERE id = $1
        LIMIT 1
      `, [
        req.user.id
      ]);

      if (
        userResult.rows.length === 0 ||
        !isSuperAdminRole(userResult.rows[0].role)
      ) {
        return res.status(404).json({
          ok: false,
          message: 'Super admin account not found.'
        });
      }

      const user = userResult.rows[0];

      if (user.password !== currentPassword) {
        return res.status(401).json({
          ok: false,
          message: 'Current password is incorrect.'
        });
      }

      const duplicateEmail = await pool.query(`
        SELECT id
        FROM users
        WHERE LOWER(email) = LOWER($1)
          AND id <> $2
        LIMIT 1
      `, [
        email,
        user.id
      ]);

      if (duplicateEmail.rows.length > 0) {
        return res.status(409).json({
          ok: false,
          message: 'That email is already used by another account.'
        });
      }

      const client = await pool.connect();
      let transactionStarted = false;
      let updatedResult;

      try {
        await client.query('BEGIN');
        transactionStarted = true;

        updatedResult = await client.query(`
          UPDATE users
          SET
            email = $1,
            password = $2
          WHERE id = $3
          RETURNING id, email, role, restaurant_id
        `, [
          email,
          newPassword || user.password,
          user.id
        ]);

        if (defaultImageProvided) {
          await client.query(`
            INSERT INTO company_settings (
              id,
              default_image
            )
            VALUES (1, $1)
            ON CONFLICT (id)
            DO UPDATE SET
              default_image = EXCLUDED.default_image,
              updated_at = NOW()
          `, [
            defaultImage
          ]);
        }

        await client.query('COMMIT');
        transactionStarted = false;
      } catch (error) {
        if (transactionStarted) {
          try {
            await client.query('ROLLBACK');
          } catch (rollbackError) {
            console.error(
              '[owner:account:update] Rollback failed:',
              rollbackError
            );
          }
        }

        throw error;
      } finally {
        client.release();
      }

      if (defaultImageProvided) {
        companySettingsCache.data = null;
      }

      const updatedUser = updatedResult.rows[0];

      const token = jwt.sign(
        {
          id: updatedUser.id,
          email: updatedUser.email,
          role: isSuperAdminRole(updatedUser.role)
            ? 'super_admin'
            : updatedUser.role,
          restaurant_id: updatedUser.restaurant_id
        },
        process.env.JWT_SECRET,
        { expiresIn: '30d' }
      );

      res.cookie(
        'adminToken',
        token,
        {
          httpOnly: true,
          sameSite: 'lax',
          secure: process.env.NODE_ENV === 'production',
          maxAge: 7 * 24 * 60 * 60 * 1000
        }
      );

      return res.json({
        ok: true,
        message: 'Super admin account updated.',
        token,
        user: {
          id: updatedUser.id,
          email: updatedUser.email,
          role: isSuperAdminRole(updatedUser.role)
            ? 'super_admin'
            : updatedUser.role
        }
      });

    } catch (error) {
      console.error(
        '[owner:account:update] Error:',
        error
      );

      if (error.code === '23505') {
        return res.status(409).json({
          ok: false,
          message: 'That email is already used by another account.'
        });
      }

      return res.status(500).json({
        ok: false,
        message: 'Unable to update super admin account.'
      });
    }
  }
);


/* ================================================================
   RESTAURANT PROFILE - GET
   ================================================================ */

app.get(
  '/api/admin/profile/:slug',
  requireRestaurantAdmin,
  async (req, res) => {
    try {
      const { slug } = req.params;

      const restaurantResult = await pool.query(`
        SELECT
          id,
          name,
          slug,
          status
        FROM restaurants
        WHERE slug = $1
        LIMIT 1
      `, [
        slug
      ]);

      if (restaurantResult.rows.length === 0) {
        return res.status(404).json({
          ok: false,
          message: 'Restaurant not found.'
        });
      }

      const restaurant =
        restaurantResult.rows[0];

      if (
        req.user.role === 'cafe_admin' &&
        Number(req.user.restaurant_id) !==
          Number(restaurant.id)
      ) {
        return res.status(403).json({
          ok: false,
          message: 'You can only access your own restaurant profile.'
        });
      }

      const profileResult = await pool.query(`
        SELECT
          logo,
          phone_numbers,
          addresses,
          updated_at
        FROM restaurant_profiles
        WHERE restaurant_id = $1
        LIMIT 1
      `, [
        restaurant.id
      ]);

      const profile =
        profileResult.rows[0] || {
          logo: '',
          phone_numbers: [],
          addresses: [],
          updated_at: null
        };

      return res.json({
        ok: true,
        restaurant,
        profile
      });

    } catch (error) {
      console.error(
        '[profile:get] Error:',
        error
      );

      return res.status(500).json({
        ok: false,
        message: 'Unable to load restaurant profile.'
      });
    }
  }
);


/* ================================================================
   RESTAURANT PROFILE - UPDATE
   ================================================================ */

app.put(
  '/api/admin/profile/:slug',
  requireRestaurantAdmin,
  async (req, res) => {
    try {
      const { slug } = req.params;

      const {
        logo = '',
        phone_numbers = [],
        addresses = []
      } = req.body;

      const restaurantResult = await pool.query(`
        SELECT
          id,
          name,
          slug,
          status
        FROM restaurants
        WHERE slug = $1
        LIMIT 1
      `, [
        slug
      ]);

      if (restaurantResult.rows.length === 0) {
        return res.status(404).json({
          ok: false,
          message: 'Restaurant not found.'
        });
      }

      const restaurant =
        restaurantResult.rows[0];

      if (
        req.user.role === 'cafe_admin' &&
        Number(req.user.restaurant_id) !==
          Number(restaurant.id)
      ) {
        return res.status(403).json({
          ok: false,
          message: 'You can only edit your own restaurant profile.'
        });
      }

      if (
        restaurant.status !== 'active' &&
        !isSuperAdminRole(req.user.role)
      ) {
        return res.status(403).json({
          ok: false,
          message: 'This restaurant is disabled.'
        });
      }

      if (
        typeof logo !== 'string' ||
        logo.length > 5000000
      ) {
        return res.status(400).json({
          ok: false,
          message: 'Invalid restaurant logo.'
        });
      }

      if (!Array.isArray(phone_numbers)) {
        return res.status(400).json({
          ok: false,
          message: 'Phone numbers must be an array.'
        });
      }

      if (!Array.isArray(addresses)) {
        return res.status(400).json({
          ok: false,
          message: 'Addresses must be an array.'
        });
      }

      await pool.query(`
        INSERT INTO restaurant_profiles (
          restaurant_id,
          logo,
          phone_numbers,
          addresses,
          updated_at
        )
        VALUES (
          $1,
          $2,
          $3::jsonb,
          $4::jsonb,
          NOW()
        )
        ON CONFLICT (restaurant_id)
        DO UPDATE SET
          logo = EXCLUDED.logo,
          phone_numbers = EXCLUDED.phone_numbers,
          addresses = EXCLUDED.addresses,
          updated_at = NOW()
      `, [
        restaurant.id,
        logo,
        JSON.stringify(phone_numbers),
        JSON.stringify(addresses)
      ]);

      menuCache.delete(slug);

      return res.json({
        ok: true,
        message: 'Restaurant profile updated successfully.'
      });

    } catch (error) {
      console.error(
        '[profile:update] Error:',
        error
      );

      return res.status(500).json({
        ok: false,
        message: 'Unable to update restaurant profile.'
      });
    }
  }
);



/* ================================================================
   RESTAURANT TELEBIRR SETTINGS
   ================================================================ */

app.get(
  '/api/admin/payment-settings/:slug',
  requireRestaurantAdmin,
  async (req, res) => {
    try {
      const { slug } = req.params;

      const restaurantResult = await pool.query(`
        SELECT id, name, slug, status
        FROM restaurants
        WHERE slug = $1
        LIMIT 1
      `, [slug]);

      if (restaurantResult.rows.length === 0) {
        return res.status(404).json({
          ok: false,
          message: 'Restaurant not found.'
        });
      }

      const restaurant = restaurantResult.rows[0];

      if (
        req.user.role === 'cafe_admin' &&
        Number(req.user.restaurant_id) !== Number(restaurant.id)
      ) {
        return res.status(403).json({
          ok: false,
          message: 'You can only manage your own restaurant payment settings.'
        });
      }

      const result = await pool.query(`
        SELECT
          telebirr_enabled,
          order_now_enabled,
          merchant_name,
          merchant_code,
          merchant_app_id,
          fabric_app_id,
          api_base_url,
          notification_url,
          return_url,
          (COALESCE(app_secret_encrypted, '') <> '') AS app_secret_configured,
          (COALESCE(private_key_encrypted, '') <> '') AS private_key_configured,
          updated_at
        FROM restaurant_payment_settings
        WHERE restaurant_id = $1
        LIMIT 1
      `, [restaurant.id]);

      return res.json({
        ok: true,
        restaurant: {
          id: restaurant.id,
          name: restaurant.name,
          slug: restaurant.slug
        },
        settings: result.rows[0] || {
          telebirr_enabled: false,
          order_now_enabled: true,
          merchant_name: '',
          merchant_code: '',
          merchant_app_id: '',
          fabric_app_id: '',
          api_base_url: '',
          notification_url: '',
          return_url: '',
          app_secret_configured: false,
          private_key_configured: false
        }
      });
    } catch (error) {
      console.error('[payment-settings:get] Error:', error.message);
      return res.status(500).json({
        ok: false,
        message: 'Unable to load payment settings.'
      });
    }
  }
);

app.put(
  '/api/admin/payment-settings/:slug',
  requireRestaurantAdmin,
  async (req, res) => {
    try {
      const { slug } = req.params;
      const {
        telebirr_enabled = false,
        order_now_enabled = true,
        merchant_name = '',
        merchant_code = '',
        merchant_app_id = '',
        fabric_app_id = '',
        app_secret = '',
        private_key = '',
        api_base_url = '',
        notification_url = '',
        return_url = ''
      } = req.body || {};

      const stringFields = [
        merchant_name,
        merchant_code,
        merchant_app_id,
        fabric_app_id,
        app_secret,
        private_key,
        api_base_url,
        notification_url,
        return_url
      ];

      if (
        typeof telebirr_enabled !== 'boolean' ||
        typeof order_now_enabled !== 'boolean' ||
        stringFields.some(value => typeof value !== 'string') ||
        merchant_name.length > 200 ||
        merchant_code.length > 200 ||
        merchant_app_id.length > 200 ||
        fabric_app_id.length > 200 ||
        app_secret.length > 10000 ||
        private_key.length > 20000 ||
        api_base_url.length > 2048 ||
        notification_url.length > 2048 ||
        return_url.length > 2048
      ) {
        return res.status(400).json({
          ok: false,
          message: 'Invalid payment settings.'
        });
      }

      if (
        !isValidTelebirrUrl(api_base_url) ||
        !isValidTelebirrUrl(notification_url) ||
        !isValidTelebirrUrl(return_url)
      ) {
        return res.status(400).json({
          ok: false,
          message: 'URLs must use HTTPS, except localhost development URLs.'
        });
      }

      const restaurantResult = await pool.query(`
        SELECT id, name, slug, status
        FROM restaurants
        WHERE slug = $1
        LIMIT 1
      `, [slug]);

      if (restaurantResult.rows.length === 0) {
        return res.status(404).json({
          ok: false,
          message: 'Restaurant not found.'
        });
      }

      const restaurant = restaurantResult.rows[0];

      if (
        req.user.role === 'cafe_admin' &&
        Number(req.user.restaurant_id) !== Number(restaurant.id)
      ) {
        return res.status(403).json({
          ok: false,
          message: 'You can only manage your own restaurant payment settings.'
        });
      }

      if (
        restaurant.status !== 'active' &&
        !isSuperAdminRole(req.user.role)
      ) {
        return res.status(403).json({
          ok: false,
          message: 'This restaurant is disabled.'
        });
      }

      // Empty secret fields preserve the existing encrypted values.
      const encryptedAppSecret = app_secret.trim()
        ? encryptTelebirrSecret(app_secret)
        : '';

      const encryptedPrivateKey = private_key.trim()
        ? encryptTelebirrSecret(private_key)
        : '';

      await pool.query(`
        INSERT INTO restaurant_payment_settings (
          restaurant_id,
          telebirr_enabled,
          order_now_enabled,
          merchant_name,
          merchant_code,
          merchant_app_id,
          fabric_app_id,
          api_base_url,
          notification_url,
          return_url,
          app_secret_encrypted,
          private_key_encrypted,
          updated_at
        )
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, NOW())
        ON CONFLICT (restaurant_id)
        DO UPDATE SET
          telebirr_enabled = EXCLUDED.telebirr_enabled,
          order_now_enabled = EXCLUDED.order_now_enabled,
          merchant_name = EXCLUDED.merchant_name,
          merchant_code = EXCLUDED.merchant_code,
          merchant_app_id = EXCLUDED.merchant_app_id,
          fabric_app_id = EXCLUDED.fabric_app_id,
          api_base_url = EXCLUDED.api_base_url,
          notification_url = EXCLUDED.notification_url,
          return_url = EXCLUDED.return_url,
          app_secret_encrypted = COALESCE(
            NULLIF(EXCLUDED.app_secret_encrypted, ''),
            restaurant_payment_settings.app_secret_encrypted
          ),
          private_key_encrypted = COALESCE(
            NULLIF(EXCLUDED.private_key_encrypted, ''),
            restaurant_payment_settings.private_key_encrypted
          ),
          updated_at = NOW()
      `, [
        restaurant.id,
        telebirr_enabled,
        order_now_enabled,
        merchant_name.trim(),
        merchant_code.trim(),
        merchant_app_id.trim(),
        fabric_app_id.trim(),
        api_base_url.trim(),
        notification_url.trim(),
        return_url.trim(),
        encryptedAppSecret,
        encryptedPrivateKey
      ]);

      return res.json({
        ok: true,
        message: 'Payment settings saved.'
      });
    } catch (error) {
      console.error('[payment-settings:update] Error:', error.message);
      return res.status(500).json({
        ok: false,
        message: 'Unable to save payment settings.'
      });
    }
  }
);
/* ================================================================
   PUBLIC MENU
   ================================================================ */

/* ================================================================
   PUBLIC MENU
   GET /api/menu/:slug
   ================================================================ */

/* ================================================================
   PUBLIC CUSTOMER MENU
   FAST VERSION
   - Does NOT load the large Base64 logo
   - Loads restaurant + menu + contact information
   - Logo is served separately
   ================================================================ */

app.get('/api/public/payment-settings/:slug', async (req, res) => {
  res.set('Cache-Control', 'no-store');

  try {
    const restaurantResult = await pool.query(`
      SELECT id
      FROM restaurants
      WHERE slug = $1
      LIMIT 1
    `, [req.params.slug]);

    if (restaurantResult.rows.length === 0) {
      return res.status(404).json({
        ok: false,
        telebirr_enabled: false,
        order_now_enabled: false
      });
    }

    const settingsResult = await pool.query(`
      SELECT telebirr_enabled, order_now_enabled, super_admin_order_now_enabled
      FROM restaurant_payment_settings
      WHERE restaurant_id = $1
      LIMIT 1
    `, [restaurantResult.rows[0].id]);

    return res.json({
      ok: true,
      telebirr_enabled:
        settingsResult.rows[0]?.telebirr_enabled === true,
      order_now_enabled:
        settingsResult.rows.length === 0 ||
        (settingsResult.rows[0]?.order_now_enabled !== false &&
        settingsResult.rows[0]?.super_admin_order_now_enabled !== false)
    });
  } catch (error) {
    console.error('[public-payment-settings] Error:', error);
    return res.status(500).json({
      ok: false,
      telebirr_enabled: false,
      order_now_enabled: false
    });
  }
});

app.get('/api/menu/:slug', async (req, res) => {
  try {
    res.set('Cache-Control', 'no-store');

    const { slug } = req.params;

    console.log(
      `[menu:get] Request received for slug: ${slug}`
    );

    const accessResult = await pool.query(`
      SELECT
        id,
        name,
        slug,
        status,
        menu_expires_at,
        menu_expires_at - (NOW() AT TIME ZONE 'UTC')::date
          AS menu_days_remaining
      FROM restaurants
      WHERE slug = $1
      LIMIT 1
    `, [
      slug
    ]);

    if (accessResult.rows.length === 0) {
      return res.status(404).json({
        ok: false,
        code: 'RESTAURANT_NOT_FOUND',
        message: 'Restaurant not found.'
      });
    }

    const accessRestaurant = accessResult.rows[0];
    const accessToken = getTokenFromRequest(req);
    let isAssignedCafeAdmin = false;

    if (accessToken) {
      try {
        const decoded = jwt.verify(
          accessToken,
          process.env.JWT_SECRET
        );

        isAssignedCafeAdmin =
          decoded.role === 'cafe_admin' &&
          Number(decoded.restaurant_id) ===
            Number(accessRestaurant.id);
      } catch (error) {
        isAssignedCafeAdmin = false;
      }
    }

    if (accessRestaurant.status !== 'active') {
      return res.status(403).json({
        ok: false,
        code: 'RESTAURANT_DISABLED',
        message: 'This restaurant is disabled. Its customer menu is unavailable.'
      });
    }

    if (
      accessRestaurant.menu_expires_at &&
      Number(accessRestaurant.menu_days_remaining) <= 0 &&
      !isAssignedCafeAdmin
    ) {
      menuCache.delete(slug);

      return res.status(410).json({
        ok: false,
        code: 'MENU_EXPIRED',
        expired: true,
        message: 'This restaurant menu has expired.',
        restaurant: {
          name: accessRestaurant.name,
          slug: accessRestaurant.slug
        },
        expirationDate: accessRestaurant.menu_expires_at,
        daysRemaining: 0
      });
    }

    /* ============================================================
       CACHE
       ============================================================ */

    if (menuCache.has(slug)) {
      console.log(
        `[menu:get] Returning cached menu for: ${slug}`
      );

      return res.json(
        {
          ...menuCache.get(slug),
          restaurant: {
            ...menuCache.get(slug).restaurant,
            menuExpirationDate:
              accessRestaurant.menu_expires_at
          }
        }
      );
    }

    /* ============================================================
       LOAD RESTAURANT + MENU + SMALL PROFILE DATA
       IMPORTANT:
       Do NOT select rp.logo here.
       The logo is approximately 4.55 MB.
       ============================================================ */

    console.log(
      `[menu:get] Loading restaurant and menu for: ${slug}`
    );

    const result = await pool.query(
      `
        SELECT
          r.id,
          r.name,
          r.slug,
          r.status,

          md.menu,
          md.updated_at AS menu_updated_at,

          rp.phone_numbers,
          rp.addresses,
          rp.updated_at AS profile_updated_at,
          ra.header_background,
          ra.restaurant_name AS appearance_restaurant_name,
          ra.restaurant_name_text,
          ra.button_background,
          ra.button_text,
          ra.selected_button,
          ra.selected_button_text,
          ra.add_button_background,
          ra.add_button_text,
          ra.cart_button_background,
          ra.cart_button_text,
          ra.card_background,
          ra.item_name,
          ra.description,
          ra.price,
          ra.page_background

        FROM restaurants r

        LEFT JOIN menu_data md
          ON md.restaurant_id = r.id

        LEFT JOIN restaurant_profiles rp
          ON rp.restaurant_id = r.id


        LEFT JOIN restaurant_appearances ra
          ON ra.restaurant_id = r.id
        WHERE r.slug = $1

        LIMIT 1
      `,
      [slug]
    );

    console.log(
      `[menu:get] Database query completed for: ${slug}`
    );

    /* ============================================================
       RESTAURANT NOT FOUND
       ============================================================ */

    if (result.rows.length === 0) {
      console.log(
        `[menu:get] Restaurant not found: ${slug}`
      );

      return res.status(404).json({
        ok: false,
        code: 'RESTAURANT_NOT_FOUND',
        message: 'Restaurant not found.'
      });
    }

    const row = result.rows[0];

    /* ============================================================
       CHECK RESTAURANT STATUS
       ============================================================ */

    if (row.status !== 'active') {
      console.log(
        `[menu:get] Restaurant is not active: ${slug}`
      );

      return res.status(403).json({
        ok: false,
        code: 'RESTAURANT_DISABLED',
        message: 'This restaurant is disabled. Its customer menu is unavailable.'
      });
    }

    /* ============================================================
       RESTAURANT
       ============================================================ */

    const restaurant = {
      id: row.id,
      name: row.name,
      slug: row.slug,
      status: row.status,
      menuExpirationDate:
        accessRestaurant.menu_expires_at
    };

    /* ============================================================
       MENU
       ============================================================ */

    const menu =
      row.menu &&
      typeof row.menu === 'object'
        ? row.menu
        : {};

    const menuUpdatedAt =
      row.menu_updated_at || null;

    /* ============================================================
       PROFILE
       IMPORTANT:
       Logo is intentionally NOT included here.
       ============================================================ */

    const profile = {
      logo: '',

      phone_numbers:
        Array.isArray(row.phone_numbers)
          ? row.phone_numbers
          : [],

      addresses:
        Array.isArray(row.addresses)
          ? row.addresses
          : [],

      updated_at:
        row.profile_updated_at || null
    };

    /* ============================================================
       BUILD RESPONSE
       ============================================================ */

    const appearance =
      row.header_background
        ? {
            header_background:
              row.header_background,

            restaurant_name:
              row.appearance_restaurant_name,

            restaurant_name_text:
              row.restaurant_name_text,

            button_background:
              row.button_background,

            button_text:
              row.button_text,

            selected_button:
              row.selected_button,

            selected_button_text:
              row.selected_button_text,

            add_button_background:
              row.add_button_background,

            add_button_text:
              row.add_button_text,

            cart_button_background:
              row.cart_button_background,

            cart_button_text:
              row.cart_button_text,

            card_background:
              row.card_background,

            item_name:
              row.item_name,

            description:
              row.description,

            price:
              row.price,

            page_background:
              row.page_background
          }
        : null;

    const responseData = {
      ok: true,

      restaurant,

      menu,

      menuUpdatedAt,

      profile,
      appearance
    };

    /* ============================================================
       CACHE
       ============================================================ */

    menuCache.set(
      slug,
      responseData
    );

    console.log(
      `[menu:get] Menu successfully loaded and cached for: ${slug}`
    );

    /* ============================================================
       SEND RESPONSE
       ============================================================ */

    return res.json(
      responseData
    );

  } catch (error) {
    console.error(
      '[menu:get] Unexpected error:',
      error
    );

    return res.status(500).json({
      ok: false,
      code: 'MENU_LOAD_FAILED',
      message: 'Unable to load menu.'
    });
  }
});


/* ================================================================
   PUBLIC RESTAURANT LOGO
   Loads the large Base64 logo separately.
   Browser caching prevents repeated downloads.
   ================================================================ */

app.get('/api/menu/:slug/logo', async (req, res) => {
  try {
    const { slug } = req.params;

    console.log(
      `[menu:logo] Request received for slug: ${slug}`
    );

    const accessResult = await pool.query(`
      SELECT
        id,
        name,
        slug,
        status,
        menu_expires_at,
        menu_expires_at - (NOW() AT TIME ZONE 'UTC')::date
          AS menu_days_remaining
      FROM restaurants
      WHERE slug = $1
      LIMIT 1
    `, [
      slug
    ]);

    if (accessResult.rows.length === 0) {
      return res.status(404).json({
        ok: false,
        message: 'Restaurant not found.'
      });
    }

    const accessRestaurant = accessResult.rows[0];
    const accessToken = getTokenFromRequest(req);
    let isAssignedCafeAdmin = false;

    if (accessToken) {
      try {
        const decoded = jwt.verify(
          accessToken,
          process.env.JWT_SECRET
        );

        isAssignedCafeAdmin =
          decoded.role === 'cafe_admin' &&
          Number(decoded.restaurant_id) ===
            Number(accessRestaurant.id);
      } catch (error) {
        isAssignedCafeAdmin = false;
      }
    }

    if (accessRestaurant.status !== 'active') {
      return res.status(403).json({
        ok: false,
        message: 'This restaurant is currently unavailable.'
      });
    }

    if (
      accessRestaurant.menu_expires_at &&
      Number(accessRestaurant.menu_days_remaining) <= 0 &&
      !isAssignedCafeAdmin
    ) {
      menuCache.delete(slug);

      return res.status(410).json({
        ok: false,
        expired: true,
        message: 'This restaurant menu has expired.',
        restaurant: {
          name: accessRestaurant.name,
          slug: accessRestaurant.slug
        },
        expirationDate: accessRestaurant.menu_expires_at,
        daysRemaining: 0
      });
    }

    /* ============================================================
       LOAD RESTAURANT FROM CACHE FIRST
       ============================================================ */

    const cachedMenu = menuCache.get(slug);

    let restaurant = cachedMenu?.restaurant || null;

    /* ============================================================
       FALLBACK TO DATABASE
       ============================================================ */

    if (!restaurant) {
      const restaurantResult = await pool.query(
        `
          SELECT
            id,
            name,
            slug,
            status
          FROM restaurants
          WHERE slug = $1
          LIMIT 1
        `,
        [slug]
      );

      if (restaurantResult.rows.length === 0) {
        console.log(
          `[menu:logo] Restaurant not found: ${slug}`
        );

        return res.status(404).json({
          ok: false,
          message: 'Restaurant not found.'
        });
      }

      restaurant = restaurantResult.rows[0];
    }

    /* ============================================================
       CHECK STATUS
       ============================================================ */

    if (restaurant.status !== 'active') {
      console.log(
        `[menu:logo] Restaurant is not active: ${slug}`
      );

      return res.status(403).json({
        ok: false,
        message: 'This restaurant is currently unavailable.'
      });
    }

    /* ============================================================
       LOAD LOGO FROM CACHE
       ============================================================ */

    let logo =
      cachedMenu?.profile?.logo || '';

    /* ============================================================
       FALLBACK TO DATABASE
       ============================================================ */

    if (!logo) {
      const logoQuery = `
          SELECT
            logo
          FROM restaurant_profiles
          WHERE restaurant_id = $1
          LIMIT 1
        `;

      let logoResult;

      try {
        logoResult = await pool.query(
          logoQuery,
          [restaurant.id]
        );
      } catch (error) {
        if (error.code !== 'ECONNRESET') {
          throw error;
        }

        console.warn(
          `[menu:logo] Retrying after PostgreSQL connection reset for ${slug}.`
        );

        logoResult = await pool.query(
          logoQuery,
          [restaurant.id]
        );
      }

      logo =
        logoResult.rows.length > 0 &&
        typeof logoResult.rows[0].logo === 'string'
          ? logoResult.rows[0].logo
          : '';
    }

    /* ============================================================
       NO LOGO
       ============================================================ */

    if (!logo) {
      return res.status(404).json({
        ok: false,
        message: 'Restaurant logo not found.'
      });
    }

    /* ============================================================
       CACHE LOGO IN BROWSER
       ============================================================ */

    res.set(
      'Cache-Control',
      'public, max-age=60, stale-while-revalidate=60'
    );

    res.set(
      'Content-Type',
      'text/plain; charset=utf-8'
    );

    console.log(
      `[menu:logo] Logo successfully loaded for: ${slug}`
    );

    return res.send(logo);

  } catch (error) {
    console.error(
      '[menu:logo] Unexpected error:',
      error
    );

    return res.status(500).json({
      ok: false,
      message: 'Unable to load restaurant logo.'
    });
  }
});

/* ================================================================
   TELEBIRR PAYMENT
   ================================================================ */

app.post(
  '/api/payments/telebirr/create',
  async (req, res) => {
    try {
      const {
        amount,
        items
      } = req.body;

      const numericAmount =
        Number(amount);

      if (
        !Number.isFinite(numericAmount) ||
        numericAmount <= 0
      ) {
        return res.status(400).json({
          ok: false,
          message: 'Invalid payment amount.'
        });
      }

      if (
        !Array.isArray(items) ||
        items.length === 0
      ) {
        return res.status(400).json({
          ok: false,
          message: 'Payment items are required.'
        });
      }

      return res.status(503).json({
        ok: false,
        code: 'TELEBIRR_CHECKOUT_NOT_CONFIGURED',
        message: 'Online Telebirr checkout is not connected yet. Merchant API access and server integration are required.'
      });

    } catch (error) {
      console.error(
        '[telebirr] Error:',
        error
      );

      return res.status(500).json({
        ok: false,
        message: 'Unable to create payment.'
      });
    }
  }
);


/* ================================================================
   RESTAURANT MENU - SAVE
   ================================================================ */

app.post(
  '/api/admin/menu/:slug',
  requireRestaurantAdmin,
  async (req, res) => {
    try {
      const { slug } = req.params;
      const { menu } = req.body;

      if (
        !menu ||
        typeof menu !== 'object' ||
        Array.isArray(menu)
      ) {
        return res.status(400).json({
          ok: false,
          message: 'Invalid menu data.'
        });
      }

      const restaurantResult = await pool.query(`
        SELECT
          id,
          name,
          slug,
          status
        FROM restaurants
        WHERE slug = $1
        LIMIT 1
      `, [
        slug
      ]);

      if (restaurantResult.rows.length === 0) {
        return res.status(404).json({
          ok: false,
          message: 'Restaurant not found.'
        });
      }

      const restaurant =
        restaurantResult.rows[0];

      if (
        req.user.role === 'cafe_admin' &&
        Number(req.user.restaurant_id) !==
          Number(restaurant.id)
      ) {
        return res.status(403).json({
          ok: false,
          message: 'You can only edit your own restaurant menu.'
        });
      }

      if (restaurant.status !== 'active') {
        return res.status(403).json({
          ok: false,
          message: 'This restaurant is disabled.'
        });
      }


      // Prevent an accidental empty save from erasing an existing menu.
      if (Object.keys(menu).length === 0) {
        const existingMenuResult = await pool.query(`
          SELECT menu
          FROM menu_data
          WHERE restaurant_id = $1
          LIMIT 1
        `, [restaurant.id]);

        const existingMenu =
          existingMenuResult.rows[0]?.menu;

        if (
          existingMenu &&
          typeof existingMenu === 'object' &&
          !Array.isArray(existingMenu) &&
          Object.keys(existingMenu).length > 0
        ) {
          return res.status(409).json({
            ok: false,
            message:
              'Empty menu save blocked because this restaurant already has menu data. Reload the menu and try again.'
          });
        }
      }

      await pool.query(`
        INSERT INTO menu_data (
          id,
          restaurant_id,
          menu,
          updated_at
        )
        VALUES (
          (
            SELECT COALESCE(MAX(id), 0) + 1
            FROM menu_data
          ),
          $1,
          $2::jsonb,
          NOW()
        )
        ON CONFLICT (restaurant_id)
        DO UPDATE SET
          menu = EXCLUDED.menu,
          updated_at = NOW()
      `, [
        restaurant.id,
        JSON.stringify(menu)
      ]);

      menuCache.delete(slug);

      return res.json({
        ok: true,
        message: 'Menu saved successfully.'
      });

    } catch (error) {
      console.error(
        '[menu:save] Error:',
        error
      );

      return res.status(500).json({
        ok: false,
        message: 'Unable to save menu.'
      });
    }
  }
);


/* ================================================================
   SUPER ADMIN
   GET RESTAURANTS
   ================================================================ */


   /* ================================================================
   PUBLIC
   RESTAURANT LIST
   ================================================================ */

app.get(
  '/api/company-restaurants',
  async (req, res) => {

    try {

      const result = await pool.query(`
        SELECT
          id,
          name,
          slug,
          status,
          menu_expires_at
        FROM restaurants
        WHERE status = 'active'
          AND (
            menu_expires_at IS NULL OR
            menu_expires_at > (NOW() AT TIME ZONE 'UTC')::date
          )
        ORDER BY id ASC
      `);

      return res.json({
        ok: true,
        restaurants: result.rows
      });

    } catch (error) {

      console.error(
        '[company:restaurants] Error:',
        error
      );

      return res.status(500).json({
        ok: false,
        message:
          'Unable to load restaurants.'
      });

    }
  }
);


/* ================================================================
   PUBLIC
   RESTAURANT LIST
   ================================================================ */

app.get(
  '/api/company-restaurants',
  async (req, res) => {

    try {

      const result = await pool.query(`
        SELECT
          id,
          name,
          slug,
          status,
          menu_expires_at
        FROM restaurants
        WHERE status = 'active'
          AND (
            menu_expires_at IS NULL OR
            menu_expires_at > (NOW() AT TIME ZONE 'UTC')::date
          )
        ORDER BY id ASC
      `);

      return res.json({
        ok: true,
        restaurants: result.rows
      });

    } catch (error) {

      console.error(
        '[company:restaurants] Error:',
        error
      );

      return res.status(500).json({
        ok: false,
        message:
          'Unable to load restaurants.'
      });

    }
  }
);

app.get(
  '/api/company-client-directory',
  async (req, res) => {
    try {
      const result = await pool.query(`
        SELECT
          r.name,
          r.slug,
          r.menu_expires_at,
          rp.phone_numbers,
          rp.addresses
        FROM restaurants r
        LEFT JOIN restaurant_profiles rp
          ON rp.restaurant_id = r.id
        WHERE r.status = 'active'
          AND (
            r.menu_expires_at IS NULL OR
            r.menu_expires_at > (NOW() AT TIME ZONE 'UTC')::date
          )
        ORDER BY r.name ASC, r.id ASC
      `);

      return res.json({
        ok: true,
        restaurants: result.rows.map(restaurant => ({
          ...restaurant,
          phone_numbers:
            Array.isArray(restaurant.phone_numbers)
              ? restaurant.phone_numbers
              : [],
          addresses:
            Array.isArray(restaurant.addresses)
              ? restaurant.addresses
              : []
        }))
      });
    } catch (error) {
      console.error(
        '[company:client-directory] Error:',
        error
      );

      return res.status(500).json({
        ok: false,
        message: 'Unable to load the client directory.'
      });
    }
  }
);

app.get(
  '/api/owner/restaurants',
  requireOwner,
  async (req, res) => {

    console.log(
      '[owner:restaurants] HANDLER STARTED'
    );

    try {

      console.log(
        '[owner:restaurants] About to query database...'
      );

      const result = await pool.query(`
        SELECT
          id,
          name,
          slug,
          status,
          menu_expires_at,
          menu_expires_at - (NOW() AT TIME ZONE 'UTC')::date
            AS menu_days_remaining,
          COALESCE((
            SELECT rps.super_admin_order_now_enabled
            FROM restaurant_payment_settings rps
            WHERE rps.restaurant_id = restaurants.id
            LIMIT 1
          ), TRUE) AS super_admin_order_now_enabled
        FROM restaurants
        ORDER BY id ASC
      `);

      console.log(
        '[owner:restaurants] Database query finished:',
        result.rows
      );

      const response = {
        ok: true,
        restaurants: result.rows
      };

      console.log(
        '[owner:restaurants] Sending response...'
      );

      return res.json(response);

    } catch (error) {

      console.error(
        '[owner:restaurants] ERROR:',
        error
      );

      return res.status(500).json({
        ok: false,
        message: error.message
      });
    }
  }
);

app.put(
  '/api/owner/restaurants/:id/self-ordering',
  requireOwner,
  async (req, res) => {
    if (!isSuperAdminRole(req.user.role)) {
      return res.status(403).json({
        ok: false,
        message: 'Super admin access required.'
      });
    }

    const restaurantId = Number(req.params.id);
    const enabled = req.body?.enabled;

    if (!Number.isInteger(restaurantId) || restaurantId <= 0) {
      return res.status(400).json({
        ok: false,
        message: 'Invalid restaurant ID.'
      });
    }

    if (typeof enabled !== 'boolean') {
      return res.status(400).json({
        ok: false,
        message: 'enabled must be a boolean.'
      });
    }

    try {
      const restaurantResult = await pool.query(
        'SELECT id FROM restaurants WHERE id = $1 LIMIT 1',
        [restaurantId]
      );

      if (restaurantResult.rows.length === 0) {
        return res.status(404).json({
          ok: false,
          message: 'Restaurant not found.'
        });
      }

      await pool.query(`
        INSERT INTO restaurant_payment_settings (
          restaurant_id,
          super_admin_order_now_enabled
        )
        VALUES ($1, $2)
        ON CONFLICT (restaurant_id)
        DO UPDATE SET
          super_admin_order_now_enabled = EXCLUDED.super_admin_order_now_enabled,
          updated_at = NOW()
      `, [restaurantId, enabled]);

      return res.json({
        ok: true,
        restaurant_id: restaurantId,
        super_admin_order_now_enabled: enabled
      });
    } catch (error) {
      console.error('[owner:self-ordering] Error:', error);
      return res.status(500).json({
        ok: false,
        message: 'Could not update self-ordering setting.'
      });
    }
  }
);

app.put(
  '/api/owner/restaurants/:id/menu-expiration',
  requireOwner,
  async (req, res) => {
    if (!isSuperAdminRole(req.user.role)) {
      return res.status(403).json({
        ok: false,
        message: 'Super admin access required.'
      });
    }

    const restaurantId = Number(req.params.id);
    const dateInput = req.body?.expirationDate;
    let expirationDate = null;

    if (
      !Number.isInteger(restaurantId) ||
      restaurantId <= 0
    ) {
      return res.status(400).json({
        ok: false,
        message: 'Invalid restaurant ID.'
      });
    }

    if (dateInput !== null && dateInput !== '') {
      if (
        typeof dateInput !== 'string' ||
        !/^\d{4}-\d{2}-\d{2}$/.test(dateInput)
      ) {
        return res.status(400).json({
          ok: false,
          message: 'Enter a valid expiration date.'
        });
      }

      const parsedDate = new Date(`${dateInput}T00:00:00.000Z`);

      if (
        Number.isNaN(parsedDate.getTime()) ||
        parsedDate.toISOString().slice(0, 10) !== dateInput
      ) {
        return res.status(400).json({
          ok: false,
          message: 'Enter a valid expiration date.'
        });
      }

      expirationDate = dateInput;
    }

    try {
      const result = await pool.query(`
        UPDATE restaurants
        SET menu_expires_at = $1::date
        WHERE id = $2
        RETURNING
          id,
          name,
          slug,
          menu_expires_at,
          menu_expires_at - (NOW() AT TIME ZONE 'UTC')::date
            AS menu_days_remaining
      `, [
        expirationDate,
        restaurantId
      ]);

      if (result.rows.length === 0) {
        return res.status(404).json({
          ok: false,
          message: 'Restaurant not found.'
        });
      }

      menuCache.delete(result.rows[0].slug);

      return res.json({
        ok: true,
        message: expirationDate
          ? 'Menu expiration date saved.'
          : 'Menu expiration date removed.',
        restaurant: result.rows[0]
      });
    } catch (error) {
      console.error(
        '[owner:restaurant:menu-expiration:update] Error:',
        error
      );

      return res.status(500).json({
        ok: false,
        message: 'Unable to update menu expiration date.'
      });
    }
  }
);


/* ================================================================
   SUPER ADMIN
   CREATE RESTAURANT
   ================================================================ */

app.post(
  '/api/owner/restaurants',
  requireOwner,
  async (req, res) => {
    const client =
      await pool.connect();

    try {
      const {
        name,
        slug,
        adminEmail,
        adminPassword
      } = req.body;

      if (
        !name ||
        !slug ||
        !adminEmail ||
        !adminPassword
      ) {
        return res.status(400).json({
          ok: false,
          message:
            'Restaurant name, slug, admin email and admin password are required.'
        });
      }

      const cleanName =
        String(name).trim();

      const cleanSlug =
        String(slug)
          .trim()
          .toLowerCase();

      const cleanEmail =
        String(adminEmail)
          .trim()
          .toLowerCase();

      const cleanPassword =
        String(adminPassword);

      if (!cleanName) {
        return res.status(400).json({
          ok: false,
          message: 'Restaurant name is required.'
        });
      }

      if (
        !/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(
          cleanSlug
        )
      ) {
        return res.status(400).json({
          ok: false,
          message:
            'Slug may contain only lowercase letters, numbers and hyphens.'
        });
      }

      if (cleanPassword.length < 6) {
        return res.status(400).json({
          ok: false,
          message:
            'Admin password must be at least 6 characters.'
        });
      }

      await client.query(
        'BEGIN'
      );

      const slugCheck =
        await client.query(`
          SELECT id
          FROM restaurants
          WHERE slug = $1
          LIMIT 1
        `, [
          cleanSlug
        ]);

      if (slugCheck.rows.length > 0) {
        await client.query(
          'ROLLBACK'
        );

        return res.status(409).json({
          ok: false,
          message:
            'That restaurant slug already exists.'
        });
      }

      const emailCheck =
        await client.query(`
          SELECT id
          FROM users
          WHERE LOWER(email) = LOWER($1)
          LIMIT 1
        `, [
          cleanEmail
        ]);

      if (emailCheck.rows.length > 0) {
        await client.query(
          'ROLLBACK'
        );

        return res.status(409).json({
          ok: false,
          message:
            'That admin email is already in use.'
        });
      }

      const restaurantResult =
        await client.query(`
          INSERT INTO restaurants (
            name,
            slug,
            status
          )
          VALUES (
            $1,
            $2,
            'active'
          )
          RETURNING
            id,
            name,
            slug,
            status
        `, [
          cleanName,
          cleanSlug
        ]);

      const restaurant =
        restaurantResult.rows[0];

      await client.query(`
        INSERT INTO menu_data (
          id,
          restaurant_id,
          menu
        )
        VALUES (
          (
            SELECT COALESCE(MAX(id), 0) + 1
            FROM menu_data
          ),
          $1,
          $2::jsonb
        )
      `, [
        restaurant.id,
        JSON.stringify({})
      ]);

      await client.query(`
        INSERT INTO restaurant_profiles (
          restaurant_id,
          logo,
          phone_numbers,
          addresses
        )
        VALUES (
          $1,
          '',
          '[]'::jsonb,
          '[]'::jsonb
        )
      `, [
        restaurant.id
      ]);

      const userResult =
        await client.query(`
          INSERT INTO users (
            email,
            password,
            role,
            restaurant_id
          )
          VALUES (
            $1,
            $2,
            'cafe_admin',
            $3
          )
          RETURNING
            id,
            email,
            role,
            restaurant_id
        `, [
          cleanEmail,
          cleanPassword,
          restaurant.id
        ]);

      await client.query(
        'COMMIT'
      );

      return res.status(201).json({
        ok: true,
        message:
          'Restaurant created successfully.',
        restaurant,
        admin: userResult.rows[0]
      });

    } catch (error) {
      try {
        await client.query(
          'ROLLBACK'
        );
      } catch (_) {}

      console.error(
        '[owner:restaurant:create] Error:',
        error
      );

      return res.status(500).json({
        ok: false,
        message:
          'Unable to create restaurant.'
      });

    } finally {
      client.release();
    }
  }
);


/* ================================================================
   SUPER ADMIN
   DUPLICATE RESTAURANT
   ================================================================ */

app.post(
  '/api/owner/restaurants/:id/duplicate',
  requireOwner,
  async (req, res) => {
    const client =
      await pool.connect();

    try {
      const sourceRestaurantId =
        Number(req.params.id);

      const {
        name,
        slug,
        adminEmail,
        adminPassword
      } = req.body;

      if (
        !Number.isInteger(sourceRestaurantId) ||
        sourceRestaurantId <= 0
      ) {
        return res.status(400).json({
          ok: false,
          message: 'Invalid source restaurant.'
        });
      }

      if (
        !name ||
        !slug ||
        !adminEmail ||
        !adminPassword
      ) {
        return res.status(400).json({
          ok: false,
          message:
            'New restaurant name, slug, admin email and admin password are required.'
        });
      }

      const cleanName =
        String(name).trim();

      const cleanSlug =
        String(slug)
          .trim()
          .toLowerCase();

      const cleanEmail =
        String(adminEmail)
          .trim()
          .toLowerCase();

      const cleanPassword =
        String(adminPassword);

      if (!cleanName) {
        return res.status(400).json({
          ok: false,
          message:
            'New restaurant name is required.'
        });
      }

      if (
        !/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(
          cleanSlug
        )
      ) {
        return res.status(400).json({
          ok: false,
          message:
            'Slug may contain only lowercase letters, numbers and hyphens.'
        });
      }

      if (cleanPassword.length < 6) {
        return res.status(400).json({
          ok: false,
          message:
            'Admin password must be at least 6 characters.'
        });
      }

      await client.query(
        'BEGIN'
      );

      /*
       * Lock the transaction while generating the legacy
       * menu_data ID using MAX(id)+1.
       */
      await client.query(`
        SELECT pg_advisory_xact_lock(847291)
      `);

      const sourceResult =
        await client.query(`
          SELECT
            id,
            name,
            slug,
            status
          FROM restaurants
          WHERE id = $1
          LIMIT 1
        `, [
          sourceRestaurantId
        ]);

      if (sourceResult.rows.length === 0) {
        await client.query(
          'ROLLBACK'
        );

        return res.status(404).json({
          ok: false,
          message:
            'Source restaurant not found.'
        });
      }

      const sourceRestaurant =
        sourceResult.rows[0];

      const slugCheck =
        await client.query(`
          SELECT id
          FROM restaurants
          WHERE slug = $1
          LIMIT 1
        `, [
          cleanSlug
        ]);

      if (slugCheck.rows.length > 0) {
        await client.query(
          'ROLLBACK'
        );

        return res.status(409).json({
          ok: false,
          message:
            'That restaurant slug already exists.'
        });
      }

      const emailCheck =
        await client.query(`
          SELECT id
          FROM users
          WHERE LOWER(email) = LOWER($1)
          LIMIT 1
        `, [
          cleanEmail
        ]);

      if (emailCheck.rows.length > 0) {
        await client.query(
          'ROLLBACK'
        );

        return res.status(409).json({
          ok: false,
          message:
            'That admin email is already in use.'
        });
      }

      const menuResult =
        await client.query(`
          SELECT
            menu
          FROM menu_data
          WHERE restaurant_id = $1
          LIMIT 1
        `, [
          sourceRestaurantId
        ]);

      const sourceMenu =
        menuResult.rows.length > 0
          ? menuResult.rows[0].menu
          : {};

      const profileResult =
        await client.query(`
          SELECT
            logo,
            phone_numbers,
            addresses
          FROM restaurant_profiles
          WHERE restaurant_id = $1
          LIMIT 1
        `, [
          sourceRestaurantId
        ]);

      const sourceProfile =
        profileResult.rows.length > 0
          ? profileResult.rows[0]
          : {
              logo: '',
              phone_numbers: [],
              addresses: []
            };

      /*
       * Create a completely new restaurant.
       */
      const newRestaurantResult =
        await client.query(`
          INSERT INTO restaurants (
            name,
            slug,
            status
          )
          VALUES (
            $1,
            $2,
            'active'
          )
          RETURNING
            id,
            name,
            slug,
            status
        `, [
          cleanName,
          cleanSlug
        ]);

      const newRestaurant =
        newRestaurantResult.rows[0];

      /*
       * Copy menu into a NEW menu_data row.
       * JSONB is copied as a new value, so future changes
       * to either restaurant are independent.
       */
      await client.query(`
        INSERT INTO menu_data (
          id,
          restaurant_id,
          menu,
          updated_at
        )
        VALUES (
          (
            SELECT COALESCE(MAX(id), 0) + 1
            FROM menu_data
          ),
          $1,
          $2::jsonb,
          NOW()
        )
      `, [
        newRestaurant.id,
        JSON.stringify(sourceMenu || {})
      ]);

      /*
       * Copy restaurant profile.
       */
      await client.query(`
        INSERT INTO restaurant_profiles (
          restaurant_id,
          logo,
          phone_numbers,
          addresses,
          updated_at
        )
        VALUES (
          $1,
          $2,
          $3::jsonb,
          $4::jsonb,
          NOW()
        )
      `, [
        newRestaurant.id,
        typeof sourceProfile.logo === 'string'
          ? sourceProfile.logo
          : '',
        JSON.stringify(
          Array.isArray(sourceProfile.phone_numbers)
            ? sourceProfile.phone_numbers
            : []
        ),
        JSON.stringify(
          Array.isArray(sourceProfile.addresses)
            ? sourceProfile.addresses
            : []
        )
      ]);

      /*
       * Create a completely separate cafe admin account.
       */
      const adminResult =
        await client.query(`
          INSERT INTO users (
            email,
            password,
            role,
            restaurant_id
          )
          VALUES (
            $1,
            $2,
            'cafe_admin',
            $3
          )
          RETURNING
            id,
            email,
            role,
            restaurant_id
        `, [
          cleanEmail,
          cleanPassword,
          newRestaurant.id
        ]);

      await client.query(
        'COMMIT'
      );

      return res.status(201).json({
        ok: true,

        message:
          'Restaurant duplicated successfully. The new restaurant is independent from the original.',

        source: {
          id: sourceRestaurant.id,
          name: sourceRestaurant.name,
          slug: sourceRestaurant.slug
        },

        restaurant: newRestaurant,

        admin: adminResult.rows[0]
      });

    } catch (error) {
      try {
        await client.query(
          'ROLLBACK'
        );
      } catch (_) {}

      console.error(
        '[owner:restaurant:duplicate] Error:',
        error
      );

      return res.status(500).json({
        ok: false,
        message:
          'Unable to duplicate restaurant.'
      });

    } finally {
      client.release();
    }
  }
);


/* ================================================================
   SUPER ADMIN
   EDIT RESTAURANT
   ================================================================ */

app.put(
  '/api/owner/restaurants/:id',
  requireOwner,
  async (req, res) => {
    try {
      const restaurantId =
        Number(req.params.id);

      const {
        name,
        slug
      } = req.body;

      if (
        !Number.isInteger(restaurantId) ||
        restaurantId <= 0
      ) {
        return res.status(400).json({
          ok: false,
          message: 'Invalid restaurant ID.'
        });
      }

      if (!name || !slug) {
        return res.status(400).json({
          ok: false,
          message:
            'Restaurant name and slug are required.'
        });
      }

      const cleanName =
        String(name).trim();

      const cleanSlug =
        String(slug)
          .trim()
          .toLowerCase();

      if (
        !/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(
          cleanSlug
        )
      ) {
        return res.status(400).json({
          ok: false,
          message:
            'Slug may contain only lowercase letters, numbers and hyphens.'
        });
      }

      const existing =
        await pool.query(`
          SELECT id
          FROM restaurants
          WHERE slug = $1
            AND id <> $2
          LIMIT 1
        `, [
          cleanSlug,
          restaurantId
        ]);

      if (existing.rows.length > 0) {
        return res.status(409).json({
          ok: false,
          message:
            'That restaurant slug already exists.'
        });
      }

      const result =
        await pool.query(`
          UPDATE restaurants
          SET
            name = $1,
            slug = $2
          WHERE id = $3
          RETURNING
            id,
            name,
            slug,
            status
        `, [
          cleanName,
          cleanSlug,
          restaurantId
        ]);

      if (result.rows.length === 0) {
        return res.status(404).json({
          ok: false,
          message:
            'Restaurant not found.'
        });
      }

      /*
       * Cache may be stored using the old slug.
       * Clear all cache entries to safely handle a slug change.
       */
      menuCache.clear();

      return res.json({
        ok: true,
        message:
          'Restaurant updated successfully.',
        restaurant:
          result.rows[0]
      });

    } catch (error) {
      console.error(
        '[owner:restaurant:update] Error:',
        error
      );

      return res.status(500).json({
        ok: false,
        message:
          'Unable to update restaurant.'
      });
    }
  }
);




/* ================================================================
   SUPER ADMIN
   RESTAURANT APPEARANCE
   ================================================================ */

app.get(
  '/api/owner/restaurants/:id/appearance',
  requireOwner,
  async (req, res) => {
    try {
      const restaurantId =
        Number(req.params.id);

      if (
        !Number.isInteger(restaurantId) ||
        restaurantId <= 0
      ) {
        return res.status(400).json({
          ok: false,
          message:
            'Invalid restaurant ID.'
        });
      }

      const restaurant =
        await pool.query(`
          SELECT
            id
          FROM restaurants
          WHERE id = $1
          LIMIT 1
        `, [
          restaurantId
        ]);

      if (restaurant.rows.length === 0) {
        return res.status(404).json({
          ok: false,
          message:
            'Restaurant not found.'
        });
      }

      const result =
        await pool.query(`
          SELECT
            header_background,
            restaurant_name,
            restaurant_name_text,
            button_background,
            button_text,
            selected_button,
            selected_button_text,
            add_button_background,
            add_button_text,
            cart_button_background,
            cart_button_text,
            card_background,
            item_name,
            description,
            price,
            page_background
          FROM restaurant_appearances
          WHERE restaurant_id = $1
          LIMIT 1
        `, [
          restaurantId
        ]);

      return res.json({
        ok: true,
        appearance:
          result.rows.length > 0
            ? result.rows[0]
            : null
      });

    } catch (error) {
      console.error(
        '[owner:restaurant:appearance:get] Error:',
        error
      );

      return res.status(500).json({
        ok: false,
        message:
          'Unable to load restaurant appearance.'
      });
    }
  }
);

app.put(
  '/api/owner/restaurants/:id/appearance',
  requireOwner,
  async (req, res) => {
    try {
      const restaurantId =
        Number(req.params.id);

      if (
        !Number.isInteger(restaurantId) ||
        restaurantId <= 0
      ) {
        return res.status(400).json({
          ok: false,
          message:
            'Invalid restaurant ID.'
        });
      }

      const restaurant =
        await pool.query(`
          SELECT
            id
          FROM restaurants
          WHERE id = $1
          LIMIT 1
        `, [
          restaurantId
        ]);

      if (restaurant.rows.length === 0) {
        return res.status(404).json({
          ok: false,
          message:
            'Restaurant not found.'
        });
      }

      const fields = [
        'header_background',
        'restaurant_name',
        'restaurant_name_text',
        'button_background',
        'button_text',
        'selected_button',
        'selected_button_text',
        'add_button_background',
        'add_button_text',
        'cart_button_background',
        'cart_button_text',
        'card_background',
        'item_name',
        'description',
        'price',
        'page_background'
      ];

      const values =
        fields.map((field) => {
          const value = req.body[field];

          if (
            value === undefined ||
            value === null
          ) {
            return null;
          }

          return String(value).trim();
        });

      const appearanceTypes =
        [
          'header_background',
          'restaurant_name',
          'button_background',
          'selected_button',
          'card_background',
          'page_background'
        ].map((field) =>
          /^linear-gradient\(/i.test(
            String(req.body[field] || '').trim()
          )
            ? 'gradient'
            : 'solid'
        );

      const result =
        await pool.query(`
          INSERT INTO restaurant_appearances (
            restaurant_id,
            header_background,
            restaurant_name,
            restaurant_name_text,
            button_background,
            button_text,
            selected_button,
            selected_button_text,
            add_button_background,
            add_button_text,
            cart_button_background,
            cart_button_text,
            card_background,
            item_name,
            description,
            price,
            page_background,
            header_background_type,
            restaurant_name_type,
            button_background_type,
            selected_button_type,
            card_background_type,
            page_background_type,
            updated_at
          )
          VALUES (
            $1,
            $2,
            $3,
            $4,
            $5,
            $6,
            $7,
            $8,
            $9,
            $10,
            $11,
            $12,
            $13,
            $14,
            $15,
            $16,
            $17,
            $18,
            $19,
            $20,
            $21,
            $22,
            $23,
            NOW()
          )
          ON CONFLICT (restaurant_id)
          DO UPDATE SET
            header_background = EXCLUDED.header_background,
            restaurant_name = EXCLUDED.restaurant_name,
            restaurant_name_text = EXCLUDED.restaurant_name_text,
            button_background = EXCLUDED.button_background,
            button_text = EXCLUDED.button_text,
            selected_button = EXCLUDED.selected_button,
            selected_button_text = EXCLUDED.selected_button_text,
            add_button_background = EXCLUDED.add_button_background,
            add_button_text = EXCLUDED.add_button_text,
            cart_button_background = EXCLUDED.cart_button_background,
            cart_button_text = EXCLUDED.cart_button_text,
            card_background = EXCLUDED.card_background,
            item_name = EXCLUDED.item_name,
            description = EXCLUDED.description,
            price = EXCLUDED.price,
            page_background = EXCLUDED.page_background,
            header_background_type = EXCLUDED.header_background_type,
            restaurant_name_type = EXCLUDED.restaurant_name_type,
            button_background_type = EXCLUDED.button_background_type,
            selected_button_type = EXCLUDED.selected_button_type,
            card_background_type = EXCLUDED.card_background_type,
            page_background_type = EXCLUDED.page_background_type,
            updated_at = NOW()
          RETURNING
            header_background,
            restaurant_name,
            restaurant_name_text,
            button_background,
            button_text,
            selected_button,
            selected_button_text,
            add_button_background,
            add_button_text,
            cart_button_background,
            cart_button_text,
            card_background,
            item_name,
            description,
            price,
            page_background
        `, [
          restaurantId,
          ...values,
          ...appearanceTypes
        ]);

      const appearance =
        result.rows[0];

      await pool.query(`
        INSERT INTO restaurant_appearance_history (
          restaurant_id,
          appearance
        )
        VALUES ($1, $2::jsonb)
      `, [
        restaurantId,
        JSON.stringify(appearance)
      ]);

      menuCache.clear();

      return res.json({
        ok: true,
        message:
          'Restaurant appearance updated successfully.',
        appearance
      });

    } catch (error) {
      console.error(
        '[owner:restaurant:appearance:update] Error:',
        error
      );

      return res.status(500).json({
        ok: false,
        message:
          'Unable to update restaurant appearance.'
      });
    }
  }
);

app.get(
  '/api/owner/restaurants/:id/appearance/history',
  requireOwner,
  async (req, res) => {
    try {
      const restaurantId = Number(req.params.id);

      if (
        !Number.isInteger(restaurantId) ||
        restaurantId <= 0
      ) {
        return res.status(400).json({
          ok: false,
          message: 'Invalid restaurant ID.'
        });
      }

      const restaurant = await pool.query(
        `SELECT id FROM restaurants WHERE id = $1 LIMIT 1`,
        [restaurantId]
      );

      if (restaurant.rows.length === 0) {
        return res.status(404).json({
          ok: false,
          message: 'Restaurant not found.'
        });
      }

      const result = await pool.query(`
        SELECT
          id,
          appearance,
          created_at
        FROM restaurant_appearance_history
        WHERE restaurant_id = $1
        ORDER BY created_at DESC, id DESC
        LIMIT 100
      `, [restaurantId]);

      return res.json({
        ok: true,
        history: result.rows
      });
    } catch (error) {
      console.error(
        '[owner:restaurant:appearance:history] Error:',
        error
      );

      return res.status(500).json({
        ok: false,
        message: 'Unable to load appearance history.'
      });
    }
  }
);


app.delete(
  '/api/owner/restaurants/:id/appearance/history/:historyId',
  requireOwner,
  async (req, res) => {
    try {
      const restaurantId = Number(req.params.id);
      const historyId = Number(req.params.historyId);

      if (
        !Number.isInteger(restaurantId) || restaurantId <= 0 ||
        !Number.isInteger(historyId) || historyId <= 0
      ) {
        return res.status(400).json({
          ok: false,
          message: 'Invalid restaurant or history ID.'
        });
      }

      const result = await pool.query(`
        DELETE FROM restaurant_appearance_history
        WHERE restaurant_id = $1 AND id = $2
        RETURNING id
      `, [restaurantId, historyId]);

      if (result.rowCount === 0) {
        return res.status(404).json({
          ok: false,
          message: 'History snapshot not found for this restaurant.'
        });
      }

      return res.json({ ok: true, deletedId: result.rows[0].id });
    } catch (error) {
      console.error('[owner:appearance:history:delete] Error:', error);
      return res.status(500).json({
        ok: false,
        message: 'Unable to delete appearance history snapshot.'
      });
    }
  }
);

app.delete(
  '/api/owner/restaurants/:id/appearance/history',
  requireOwner,
  async (req, res) => {
    try {
      const restaurantId = Number(req.params.id);

      if (!Number.isInteger(restaurantId) || restaurantId <= 0) {
        return res.status(400).json({
          ok: false,
          message: 'Invalid restaurant ID.'
        });
      }

      const restaurant = await pool.query(
        'SELECT id FROM restaurants WHERE id = $1 LIMIT 1',
        [restaurantId]
      );

      if (restaurant.rows.length === 0) {
        return res.status(404).json({
          ok: false,
          message: 'Restaurant not found.'
        });
      }

      const result = await pool.query(`
        DELETE FROM restaurant_appearance_history
        WHERE restaurant_id = $1
      `, [restaurantId]);

      return res.json({
        ok: true,
        deletedCount: result.rowCount
      });
    } catch (error) {
      console.error('[owner:appearance:history:clear] Error:', error);
      return res.status(500).json({
        ok: false,
        message: 'Unable to clear appearance history.'
      });
    }
  }
);

app.delete(
  '/api/owner/restaurants/:id/appearance',
  requireOwner,
  async (req, res) => {
    try {
      const restaurantId =
        Number(req.params.id);

      if (
        !Number.isInteger(restaurantId) ||
        restaurantId <= 0
      ) {
        return res.status(400).json({
          ok: false,
          message:
            'Invalid restaurant ID.'
        });
      }

      const restaurant =
        await pool.query(`
          SELECT
            id
          FROM restaurants
          WHERE id = $1
          LIMIT 1
        `, [
          restaurantId
        ]);

      if (restaurant.rows.length === 0) {
        return res.status(404).json({
          ok: false,
          message:
            'Restaurant not found.'
        });
      }

      await pool.query(`
        DELETE FROM restaurant_appearances
        WHERE restaurant_id = $1
      `, [
        restaurantId
      ]);

      menuCache.clear();

      return res.json({
        ok: true,
        message:
          'Restaurant appearance reset successfully.'
      });

    } catch (error) {
      console.error(
        '[owner:restaurant:appearance:delete] Error:',
        error
      );

      return res.status(500).json({
        ok: false,
        message:
          'Unable to reset restaurant appearance.'
      });
    }
  }
);


/* ================================================================
   SUPER ADMIN
   UPDATE RESTAURANT ADMIN ACCOUNT
   ================================================================ */

app.get(
  '/api/owner/restaurants/:id/admin',
  requireOwner,
  async (req, res) => {
    try {
      const restaurantId =
        Number(req.params.id);

      if (
        !Number.isInteger(restaurantId) ||
        restaurantId <= 0
      ) {
        return res.status(400).json({
          ok: false,
          message:
            'Invalid restaurant ID.'
        });
      }

      const result =
        await pool.query(`
          SELECT
            id,
            email,
            password,
            role,
            restaurant_id
          FROM users
          WHERE restaurant_id = $1
            AND role = 'cafe_admin'
          ORDER BY id ASC
          LIMIT 1
        `, [
          restaurantId
        ]);

      if (result.rows.length === 0) {
        return res.status(404).json({
          ok: false,
          message:
            'Restaurant admin account not found.'
        });
      }

      const admin =
        result.rows[0];

      return res.json({
        ok: true,
        admin: {
          id: admin.id,
          email: admin.email,
          password: admin.password,
          role: admin.role,
          restaurantId: admin.restaurant_id
        }
      });

    } catch (error) {
      console.error(
        '[owner:restaurant:admin:get] Error:',
        error
      );

      return res.status(500).json({
        ok: false,
        message:
          'Unable to load restaurant admin account.'
      });
    }
  }
);

app.put(
  '/api/owner/restaurants/:id/admin',
  requireOwner,
  async (req, res) => {
    try {
      const restaurantId =
        Number(req.params.id);

      const {
        email,
        password
      } = req.body;

      if (
        !Number.isInteger(restaurantId) ||
        restaurantId <= 0
      ) {
        return res.status(400).json({
          ok: false,
          message: 'Invalid restaurant ID.'
        });
      }

      if (!email) {
        return res.status(400).json({
          ok: false,
          message: 'Admin email is required.'
        });
      }

      const cleanEmail =
        String(email)
          .trim()
          .toLowerCase();

      const cleanPassword =
        password === undefined ||
        password === null
          ? ''
          : String(password);

      if (
        cleanPassword &&
        cleanPassword.length < 6
      ) {
        return res.status(400).json({
          ok: false,
          message:
            'Password must be at least 6 characters.'
        });
      }

      const restaurantResult =
        await pool.query(`
          SELECT id
          FROM restaurants
          WHERE id = $1
          LIMIT 1
        `, [
          restaurantId
        ]);

      if (restaurantResult.rows.length === 0) {
        return res.status(404).json({
          ok: false,
          message:
            'Restaurant not found.'
        });
      }

      const emailCheck =
        await pool.query(`
          SELECT id
          FROM users
          WHERE LOWER(email) = LOWER($1)
            AND restaurant_id <> $2
          LIMIT 1
        `, [
          cleanEmail,
          restaurantId
        ]);

      if (emailCheck.rows.length > 0) {
        return res.status(409).json({
          ok: false,
          message:
            'That email is already used by another account.'
        });
      }

      const adminResult =
        await pool.query(`
          SELECT
            id,
            email,
            password
          FROM users
          WHERE restaurant_id = $1
            AND role = 'cafe_admin'
          ORDER BY id ASC
          LIMIT 1
        `, [
          restaurantId
        ]);

      if (adminResult.rows.length === 0) {
        const insertResult =
          await pool.query(`
            INSERT INTO users (
              email,
              password,
              role,
              restaurant_id
            )
            VALUES (
              $1,
              $2,
              'cafe_admin',
              $3
            )
            RETURNING
              id,
              email,
              role,
              restaurant_id
          `, [
            cleanEmail,
            cleanPassword,
            restaurantId
          ]);

        return res.json({
          ok: true,
          message:
            'Restaurant admin account created.',
          admin:
            insertResult.rows[0]
        });
      }

      const admin =
        adminResult.rows[0];

      if (cleanPassword) {
        const result =
          await pool.query(`
            UPDATE users
            SET
              email = $1,
              password = $2
            WHERE id = $3
            RETURNING
              id,
              email,
              role,
              restaurant_id
          `, [
            cleanEmail,
            cleanPassword,
            admin.id
          ]);

        return res.json({
          ok: true,
          message:
            'Restaurant admin account updated.',
          admin:
            result.rows[0]
        });
      }

      const result =
        await pool.query(`
          UPDATE users
          SET
            email = $1
          WHERE id = $2
          RETURNING
            id,
            email,
            role,
            restaurant_id
        `, [
          cleanEmail,
          admin.id
        ]);

      return res.json({
        ok: true,
        message:
          'Restaurant admin email updated.',
        admin:
          result.rows[0]
      });

    } catch (error) {
      console.error(
        '[owner:restaurant:admin] Error:',
        error
      );

      return res.status(500).json({
        ok: false,
        message:
          'Unable to update restaurant admin account.'
      });
    }
  }
);


/* ================================================================
   SUPER ADMIN
   CHANGE RESTAURANT STATUS
   ================================================================ */

app.post(
  '/api/owner/verify-action-password',
  requireOwner,
  async (req, res) => {
    if (!isSuperAdminRole(req.user.role)) {
      return res.status(403).json({
        ok: false,
        message: 'Super admin access required.'
      });
    }

    const password =
      typeof req.body?.password === 'string'
        ? req.body.password
        : '';

    if (!password) {
      return res.status(400).json({
        ok: false,
        message: 'Enter your super admin password to continue.'
      });
    }

    try {
      const result = await pool.query(`
        SELECT password, role
        FROM users
        WHERE id = $1
        LIMIT 1
      `, [
        req.user.id
      ]);

      if (result.rows.length === 0) {
        return res.status(403).json({
          ok: false,
          message: 'Super admin account not found.'
        });
      }

      if (!isSuperAdminRole(result.rows[0].role)) {
        return res.status(403).json({
          ok: false,
          message: 'Super admin access required.'
        });
      }

      if (result.rows[0].password !== password) {
        return res.status(401).json({
          ok: false,
          message: 'Super admin password is incorrect.'
        });
      }

      return res.json({
        ok: true,
        message: 'Password verified.'
      });
    } catch (error) {
      console.error(
        '[owner:action-password:verify] Error:',
        error
      );

      return res.status(500).json({
        ok: false,
        message: 'Unable to verify your super admin password.'
      });
    }
  }
);

app.put(
  '/api/owner/restaurants/:id/status',
  requireOwner,
  requireSuperAdminPassword,
  async (req, res) => {
    try {
      const restaurantId =
        Number(req.params.id);

      const {
        status
      } = req.body;

      if (
        !Number.isInteger(restaurantId) ||
        restaurantId <= 0
      ) {
        return res.status(400).json({
          ok: false,
          message:
            'Invalid restaurant ID.'
        });
      }

      if (
        status !== 'active' &&
        status !== 'disabled'
      ) {
        return res.status(400).json({
          ok: false,
          message:
            'Status must be active or disabled.'
        });
      }

      const result =
        await pool.query(`
          UPDATE restaurants
          SET status = $1
          WHERE id = $2
          RETURNING
            id,
            name,
            slug,
            status
        `, [
          status,
          restaurantId
        ]);

      if (result.rows.length === 0) {
        return res.status(404).json({
          ok: false,
          message:
            'Restaurant not found.'
        });
      }

      menuCache.clear();

      return res.json({
        ok: true,
        message:
          status === 'active'
            ? 'Restaurant enabled successfully.'
            : 'Restaurant disabled successfully.',
        restaurant:
          result.rows[0]
      });

    } catch (error) {
      console.error(
        '[owner:restaurant:status] Error:',
        error
      );

      return res.status(500).json({
        ok: false,
        message:
          'Unable to update restaurant status.'
      });
    }
  }
);


/* ================================================================
   SUPER ADMIN
   PRICE MANAGEMENT
   ================================================================ */

app.post(
  '/api/owner/restaurants/:id/price-management',
  requireOwner,
  async (req, res) => {
    const client =
      await pool.connect();

    try {
      const restaurantId =
        Number(req.params.id);

        

      const {
        mode,
        percentage,
        scope,
        category,
        items
      } = req.body;

      /* ------------------------------------------------------------
         VALIDATE RESTAURANT ID
         ------------------------------------------------------------ */

      if (
        !Number.isInteger(restaurantId) ||
        restaurantId <= 0
      ) {
        return res.status(400).json({
          ok: false,
          message:
            'Invalid restaurant ID.'
        });
      }

      /* ------------------------------------------------------------
         VALIDATE MODE
         ------------------------------------------------------------ */

      if (
        mode !== 'increase' &&
        mode !== 'decrease'
      ) {
        return res.status(400).json({
          ok: false,
          message:
            'Price operation must be increase or decrease.'
        });
      }

      /* ------------------------------------------------------------
         VALIDATE PERCENTAGE
         ------------------------------------------------------------ */

      const numericPercentage =
        Number(percentage);

        console.log(
  '[PRICE DEBUG] received percentage:',
  percentage,
  'numeric:',
  numericPercentage
);

      if (
        !Number.isFinite(numericPercentage) ||
        numericPercentage < 0
      ) {
        return res.status(400).json({
          ok: false,
          message:
            'Percentage must be 0 or greater.'
        });
      }

      if (numericPercentage > 1000) {
        return res.status(400).json({
          ok: false,
          message:
            'Percentage cannot be greater than 1000%.'
        });
      }

      /*
       * A 100% decrease would make every price zero.
       * We require a value below 100%.
       */
      if (
        mode === 'decrease' &&
        numericPercentage >= 100
      ) {
        return res.status(400).json({
          ok: false,
          message:
            'Decrease percentage must be less than 100%.'
        });
      }

      /* ------------------------------------------------------------
         VALIDATE SCOPE
         ------------------------------------------------------------ */

      if (
        scope !== 'all' &&
        scope !== 'category' &&
        scope !== 'items'
      ) {
        return res.status(400).json({
          ok: false,
          message:
            'Invalid price management scope.'
        });
      }

      if (
        scope === 'category' &&
        (
          typeof category !== 'string' ||
          !category.trim()
        )
      ) {
        return res.status(400).json({
          ok: false,
          message:
            'A category is required.'
        });
      }

      if (
        scope === 'items' &&
        (
          !Array.isArray(items) ||
          items.length === 0
        )
      ) {
        return res.status(400).json({
          ok: false,
          message:
            'At least one menu item must be selected.'
        });
      }

      if (
        Array.isArray(items) &&
        items.length > 1000
      ) {
        return res.status(400).json({
          ok: false,
          message:
            'Too many menu items selected.'
        });
      }

      /* ------------------------------------------------------------
         START TRANSACTION
         ------------------------------------------------------------ */

      await client.query(
        'BEGIN'
      );

      /*
       * Lock the same advisory lock used by the manual
       * menu_data ID generator.
       */
      await client.query(`
        SELECT pg_advisory_xact_lock(847291)
      `);

      /* ------------------------------------------------------------
         LOAD RESTAURANT
         ------------------------------------------------------------ */

      const restaurantResult =
        await client.query(`
          SELECT
            id,
            name,
            slug,
            status
          FROM restaurants
          WHERE id = $1
          LIMIT 1
        `, [
          restaurantId
        ]);

      if (restaurantResult.rows.length === 0) {
        await client.query(
          'ROLLBACK'
        );

        return res.status(404).json({
          ok: false,
          message:
            'Restaurant not found.'
        });
      }

      const restaurant =
        restaurantResult.rows[0];

      /*
       * Price management only operates on active restaurants.
       */
      if (restaurant.status !== 'active') {
        await client.query(
          'ROLLBACK'
        );

        return res.status(403).json({
          ok: false,
          message:
            'Price management is only available for active restaurants.'
        });
      }

      /* ------------------------------------------------------------
         LOAD MENU WITH ROW LOCK
         ------------------------------------------------------------ */

      const menuResult =
        await client.query(`
          SELECT
            menu
          FROM menu_data
          WHERE restaurant_id = $1
          FOR UPDATE
        `, [
          restaurantId
        ]);

      if (menuResult.rows.length === 0) {
        await client.query(
          'ROLLBACK'
        );

        return res.status(404).json({
          ok: false,
          message:
            'No menu data exists for this restaurant.'
        });
      }

      const originalMenu =
        menuResult.rows[0].menu || {};

      /*
       * Deep clone JSONB so we don't mutate the object
       * returned by pg unexpectedly.
       */
      const updatedMenu =
        JSON.parse(
          JSON.stringify(originalMenu)
        );

      /* ------------------------------------------------------------
         BUILD SELECTION
         ------------------------------------------------------------ */

      const selectedItems =
        Array.isArray(items)
          ? items
          : [];

      const selectedItemKeys =
        new Set();

      for (
        const selectedItem
        of selectedItems
      ) {
        if (
          !selectedItem ||
          typeof selectedItem !== 'object'
        ) {
          continue;
        }

        const selectedCategory =
          typeof selectedItem.category === 'string'
            ? selectedItem.category
            : '';

        const selectedIndex =
          Number(selectedItem.index);

        if (
          selectedCategory &&
          Number.isInteger(selectedIndex) &&
          selectedIndex >= 0
        ) {
          selectedItemKeys.add(
            `${selectedCategory}::${selectedIndex}`
          );
        }
      }

      if (
        scope === 'items' &&
        selectedItemKeys.size === 0
      ) {
        await client.query(
          'ROLLBACK'
        );

        return res.status(400).json({
          ok: false,
          message:
            'No valid menu items were selected.'
        });
      }

      /* ------------------------------------------------------------
         CALCULATE PRICE MULTIPLIER
         ------------------------------------------------------------ */

      const multiplier =
        mode === 'increase'
          ? 1 + numericPercentage / 100
          : 1 - numericPercentage / 100;

      /* ------------------------------------------------------------
         PRICE MANAGEMENT
         ------------------------------------------------------------ */

      let affectedCount = 0;
      let skippedCount = 0;

      const changedItems = [];

      for (
        const categoryName of Object.keys(
          updatedMenu
        )
      ) {
        const categoryItems =
          updatedMenu[categoryName];

        if (!Array.isArray(categoryItems)) {
          continue;
        }

        /*
         * Category scope.
         */
        if (
          scope === 'category' &&
          categoryName !== category.trim()
        ) {
          continue;
        }

        for (
          let index = 0;
          index < categoryItems.length;
          index++
        ) {
          const item =
            categoryItems[index];

          if (
            !item ||
            typeof item !== 'object'
          ) {
            skippedCount++;
            continue;
          }

          /*
           * Selected items scope.
           */
          if (scope === 'items') {
            const key =
              `${categoryName}::${index}`;

            if (
              !selectedItemKeys.has(key)
            ) {
              continue;
            }
          }

          /*
           * Only numeric prices can be updated.
           */
          const oldPrice =
            Number(item.price);

          if (
            !Number.isFinite(oldPrice) ||
            oldPrice < 0
          ) {
            skippedCount++;
            continue;
          }

          const rawNewPrice =
            oldPrice * multiplier;

          /*
           * Consistent two-decimal rounding.
           */
          const newPrice =
            Math.round(rawNewPrice);

          item.price =
            newPrice;

          affectedCount++;

          changedItems.push({
            category: categoryName,
            index,
            name:
              typeof item.name === 'string'
                ? item.name
                : `Item ${index + 1}`,
            oldPrice,
            newPrice
          });
        }
      }

      if (affectedCount === 0) {
        await client.query(
          'ROLLBACK'
        );

        return res.status(400).json({
          ok: false,
          message:
            'No menu items with valid prices were found for this operation.'
        });
      }

      /* ------------------------------------------------------------
         SAVE UPDATED MENU
         ------------------------------------------------------------ */

      await client.query(`
        UPDATE menu_data
        SET
          menu = $1::jsonb,
          updated_at = NOW()
        WHERE restaurant_id = $2
      `, [
        JSON.stringify(updatedMenu),
        restaurantId
      ]);

      await client.query(
        'COMMIT'
      );

      /*
       * Clear cached public menu so the new prices appear.
       */
      menuCache.delete(
        restaurant.slug
      );

      return res.json({
        ok: true,

        message:
          mode === 'increase'
            ? `Prices increased by ${numericPercentage}% for ${affectedCount} item${affectedCount === 1 ? '' : 's'}.`
            : `Prices decreased by ${numericPercentage}% for ${affectedCount} item${affectedCount === 1 ? '' : 's'}.`,

        restaurant: {
          id: restaurant.id,
          name: restaurant.name,
          slug: restaurant.slug
        },

        operation: {
          mode,
          percentage: numericPercentage,
          scope,
          category:
            scope === 'category'
              ? category.trim()
              : null
        },

        affectedCount,
        skippedCount,
        changedItems
      });

    } catch (error) {
      try {
        await client.query(
          'ROLLBACK'
        );
      } catch (_) {}

      console.error(
        '[owner:price-management] Error:',
        error
      );

      return res.status(500).json({
        ok: false,
        message:
          'Unable to update menu prices.'
      });

    } finally {
      client.release();
    }
  }
);


/* ================================================================
   SUPER ADMIN
   DELETE RESTAURANT
   ================================================================ */

app.delete(
  '/api/owner/restaurants/:id',
  requireOwner,
  requireSuperAdminPassword,
  async (req, res) => {
    const client =
      await pool.connect();

    try {
      const restaurantId =
        Number(req.params.id);

      if (
        !Number.isInteger(restaurantId) ||
        restaurantId <= 0
      ) {
        return res.status(400).json({
          ok: false,
          message:
            'Invalid restaurant ID.'
        });
      }

      await client.query(
        'BEGIN'
      );

      const restaurantResult =
        await client.query(`
          SELECT
            id,
            name,
            slug
          FROM restaurants
          WHERE id = $1
          LIMIT 1
        `, [
          restaurantId
        ]);

      if (restaurantResult.rows.length === 0) {
        await client.query(
          'ROLLBACK'
        );

        return res.status(404).json({
          ok: false,
          message:
            'Restaurant not found.'
        });
      }

      const restaurant =
        restaurantResult.rows[0];

      /*
       * Delete cafe admin accounts.
       */
      await client.query(`
        DELETE FROM users
        WHERE restaurant_id = $1
          AND role = 'cafe_admin'
      `, [
        restaurantId
      ]);

      /*
       * Delete menu data.
       */
      await client.query(`
        DELETE FROM menu_data
        WHERE restaurant_id = $1
      `, [
        restaurantId
      ]);

      /*
       * restaurant_profiles will also be removed through
       * ON DELETE CASCADE, but explicitly deleting it keeps
       * this operation clear and safe if the schema changes.
       */
      await client.query(`
        DELETE FROM restaurant_profiles
        WHERE restaurant_id = $1
      `, [
        restaurantId
      ]);

      /*
       * Delete restaurant.
       */
      await client.query(`
        DELETE FROM restaurants
        WHERE id = $1
      `, [
        restaurantId
      ]);

      await client.query(
        'COMMIT'
      );

      menuCache.delete(
        restaurant.slug
      );

      return res.json({
        ok: true,
        message:
          'Restaurant deleted successfully.',
        restaurant
      });

    } catch (error) {
      try {
        await client.query(
          'ROLLBACK'
        );
      } catch (_) {}

      console.error(
        '[owner:restaurant:delete] Error:',
        error
      );

      return res.status(500).json({
        ok: false,
        message:
          'Unable to delete restaurant.'
      });

    } finally {
      client.release();
    }
  }
);

/* ================================================================
   PUBLIC
   COMPANY SETTINGS
   ================================================================ */

app.get(
  '/api/company-settings',
  async (req, res) => {
    try {

      if (companySettingsCache.data) {
        return res.json(companySettingsCache.data);
      }

      const result = await pool.query(`
        SELECT
          company_name,
          slogan,
          phone,
          phone_numbers,
          email,
          address,
          logo,
          default_image,
          about,
          company_content,
          addresses
        FROM company_settings
        WHERE id = 1
        LIMIT 1
      `);

      if (result.rows.length === 0) {

        const emptyResponse = {
          ok: true,
          settings: {
            companyName: '',
            slogan: '',
            phone: '',
            phoneNumbers: [],
            email: '',
            address: '',
            logo: '',
            defaultImage: '',
            about: '',
            addresses: []
          }
        };

        companySettingsCache.data = emptyResponse;

        return res.json(emptyResponse);
      }

      const row = result.rows[0];

      const response = {
        ok: true,
        settings: {
          companyName: row.company_name || '',
          slogan: row.slogan || '',
          phone: row.phone || '',
          phoneNumbers:
            Array.isArray(row.phone_numbers) &&
            row.phone_numbers.length > 0
              ? row.phone_numbers
              : (row.phone ? [row.phone] : []),
          email: row.email || '',
          address: row.address || '',
          logo: row.logo || '',
          defaultImage: row.default_image || '',
          about: row.about || '',
          companyContent:
            row.company_content &&
            typeof row.company_content === 'object'
              ? row.company_content
              : {},
          addresses:
            Array.isArray(row.addresses)
              ? row.addresses
              : []
        }
      };

      companySettingsCache.data = response;

      return res.json(response);

    } catch (error) {
      console.error(
        '[company-settings:public] Error:',
        error
      );

      return res.status(500).json({
        ok: false,
        message:
          'Unable to load company settings.'
      });
    }
  }
);


/* ================================================================
   SUPER ADMIN
   COMPANY SETTINGS
   GET COMPANY SETTINGS
   ================================================================ */

app.get(
  '/api/owner/company-settings',
  requireOwner,
  async (req, res) => {
    try {

      if (companySettingsCache.data) {
        return res.json(companySettingsCache.data);
      }

      const result = await pool.query(`
        SELECT
          company_name,
          slogan,
          phone,
          phone_numbers,
          email,
          address,
          logo,
          default_image,
          about,
          company_content,
          addresses
        FROM company_settings
        WHERE id = 1
        LIMIT 1
      `);

      if (result.rows.length === 0) {

        const emptyResponse = {
          ok: true,
          settings: {
            companyName: '',
            slogan: '',
            phone: '',
            phoneNumbers: [],
            email: '',
            address: '',
            logo: '',
            defaultImage: '',
            about: '',
            addresses: []
          }
        };

        companySettingsCache.data = emptyResponse;

        return res.json(emptyResponse);
      }

      const row = result.rows[0];

      const response = {
        ok: true,
        settings: {
          companyName: row.company_name || '',
          slogan: row.slogan || '',
          phone: row.phone || '',
          phoneNumbers:
            Array.isArray(row.phone_numbers) &&
            row.phone_numbers.length > 0
              ? row.phone_numbers
              : (row.phone ? [row.phone] : []),
          email: row.email || '',
          address: row.address || '',
          logo: row.logo || '',
          defaultImage: row.default_image || '',
          about: row.about || '',
          companyContent:
            row.company_content &&
            typeof row.company_content === 'object'
              ? row.company_content
              : {},
          addresses:
            Array.isArray(row.addresses)
              ? row.addresses
              : []
        }
      };

      companySettingsCache.data = response;

      return res.json(response);

    } catch (error) {
      console.error(
        '[owner:company-settings:get] Error:',
        error
      );

      return res.status(500).json({
        ok: false,
        message:
          'Unable to load company settings.'
      });
    }
  }
);


/* ================================================================
   SUPER ADMIN
   COMPANY SETTINGS
   UPDATE COMPANY SETTINGS
   ================================================================ */

app.put(
  '/api/owner/company-settings',
  requireOwner,
  async (req, res) => {
    try {
      const {
    companyName,
    slogan,
    phone,
    phoneNumbers,
    addresses,
    email,
    address,
    logo,
    about,
    companyContent
} = req.body;

      const normalizedPhoneNumbers = Array.isArray(phoneNumbers)
  ? phoneNumbers.map(value => String(value || '').trim()).filter(Boolean)
  : [];

const primaryPhone = String(phone || normalizedPhoneNumbers[0] || '').trim();

const normalizedAddresses = Array.isArray(addresses)
  ? addresses
      .map(location => ({
          name: String(location?.name || '').trim(),
          url: String(location?.url || '').trim()
      }))
      .filter(location => location.name)
  : [];


      await pool.query(`
        INSERT INTO company_settings (
          id,
          company_name,
          slogan,
          phone,
          phone_numbers,
          addresses,
          email,
          address,
          logo,
          about,
          company_content,
          updated_at
        )
        VALUES (
  1,
  $1,
  $2,
  $3,
  $4,
  $5,
  $6,
  $7,
  $8,
  $9,  $10,

  NOW()
)
        ON CONFLICT (id)
        DO UPDATE SET
  company_name = EXCLUDED.company_name,
  slogan = EXCLUDED.slogan,
  phone = EXCLUDED.phone,
  phone_numbers = EXCLUDED.phone_numbers,
  addresses = EXCLUDED.addresses,
  email = EXCLUDED.email,
  address = EXCLUDED.address,
  logo = EXCLUDED.logo,
  about = EXCLUDED.about,
  company_content = EXCLUDED.company_content,
  updated_at = NOW()
      `, [
        String(companyName || '').trim(),
        String(slogan || '').trim(),
        primaryPhone,
        JSON.stringify(normalizedPhoneNumbers),
        JSON.stringify(normalizedAddresses),
        String(email || '').trim(),
        String(address || '').trim(),
        String(logo || ''),
        String(about || '').trim(),
        JSON.stringify(Array.isArray(companyContent) ? companyContent : [])
      ]);

      companySettingsCache.data = null;

      return res.json({
        ok: true,
        message:
          'Company settings saved successfully.'
      });

    } catch (error) {
      console.error(
        '[owner:company-settings:update] Error:',
        error
      );

      return res.status(500).json({
        ok: false,
        message:
          'Unable to save company settings.'
      });
    }
  }
);

/* ================================================================
   API 404
   ================================================================ */

app.use(
  '/api',
  (req, res) => {
    return res.status(404).json({
      ok: false,
      message: 'API endpoint not found.'
    });
  }
);


/* ================================================================
   GENERAL ERROR HANDLER
   ================================================================ */

app.use(
  (error, req, res, next) => {
    console.error(
      '[server] Unhandled error:',
      error
    );

    if (res.headersSent) {
      return next(error);
    }

    return res.status(500).json({
      ok: false,
      message:
        'Internal server error.'
    });
  }
);




/* ================================================================
   SERVER START
   ================================================================ */

const PORT = Number(process.env.PORT) || 10000;

async function startServer() {
  try {
    await ensureDatabaseStructure();
    await pool.query(`
      ALTER TABLE restaurants
      ADD COLUMN IF NOT EXISTS menu_expires_at DATE
    `);

    /*
       Establish the PostgreSQL connection before accepting
       customer traffic.
    */
    await warmDatabaseConnection();

    /*
       Warm the public menu cache before accepting
       customer traffic.
    */
    await warmMenuCache();

    app.listen(PORT, '0.0.0.0', () => {
    console.log(`[server] Caffemenu running on port ${PORT}`);
});

  } catch (error) {
    console.error('[server] Failed to start:', error);
    process.exit(1);
  }
}

startServer();
